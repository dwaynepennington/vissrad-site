# Switching to a Different Project XML

This dashboard is built to be reused. You do **not** rebuild anything to load a new
project — you swap the source file and click **Refresh**. Every visual, KPI card,
slicer, and date range re-scales to the new project automatically.

---

## The one rule that makes it work

The dashboard reads a **P6 PM/XML** export — the file you get from P6 with:

> **File → Export → Primavera P6 XML**

It is **not** an `.xer` file, and **not** an MS Project XML. As long as the new file
is that same P6 PM/XML export type, everything flows through automatically.

---

## Option A — Simplest: reuse the same folder (recommended)

This is why the `XML_Folder` parameter points at a **folder**, not one file.

1. Export the new project from P6 as **P6 XML**.
2. Drop that `.xml` file into your `C:\xml` folder.
3. Open the dashboard and click **Home → Refresh**.

The query automatically picks the **newest `.xml` file** in the folder (by date
modified), so the most recently exported project wins. You can leave old exports in
the folder for history — only the latest one loads.

---

## Option B — Point directly at one specific file

If you want to control exactly which file loads (not "newest wins"):

1. **Home → Transform data → Edit Parameters**
2. Set `XML_Folder` to the **full file path**, e.g.
   `C:\Projects\PlantB\PlantB-EPC.xml`
3. **OK → Refresh**

The `XML_Folder` parameter accepts **either**:
- a **folder** (e.g. `C:\xml`) → loads the newest `.xml` in it, **or**
- a **full file path** ending in `.xml` → loads exactly that one file.

No quotes either way.

---

## Option C — New project, new folder

1. Put the new export anywhere, e.g. `C:\Projects\PlantB\`.
2. **Home → Transform data → Edit Parameters** → set `XML_Folder` = `C:\Projects\PlantB` (no quotes).
3. **OK → Refresh**

---

## Changing the blended rate for a different project

Same screen. **Home → Transform data → Edit Parameters → `BlendedRate`** = your
number (e.g. `110`) → **Refresh**. All costs recalculate at the new rate.

---

## What updates automatically vs. what to expect

When you refresh against a new project's XML:

**Auto-updates (no work from you):**
- Activities, WBS, resources, man-hours
- All FTE / schedule / cost visuals, KPI cards, and the S-curve
- Contractor and discipline slicers
- Date ranges and every page's scaling

**Actual / Committed columns:**
- Populate **on their own** if the new export is a **progressed (statused)** schedule
  — no rebuild needed.
- Stay at **0** on a pure baseline export (nothing done yet) — this is correct
  behavior, not an error.

**Contractor / discipline breakdown:**
- Relies on the resource-ID prefix convention: `BRCX-SUB…` = Subcontractor,
  `BRCX-PRF…` = Self-Perform, everything else = Direct / Engineering.
- If a new project uses **different resource codes**, the slicers still work, but the
  Subcontractor / Self-Perform / Direct grouping may need a one-line tweak.

---

## If a refresh ever errors

Two things cause almost every issue:

1. **Wrong export type** — it must be P6 **PM/XML**, not `.xer` and not MS Project XML.
2. **Path formatting** — no quotes, and the folder must actually contain a `.xml` file.
   - Correct: `C:\xml`
   - Wrong:   `"C:\xml"`  (the quote characters cause "illegal characters in path")

If it still errors, note the **exact table name** and the **error message** shown in
Power Query — that pinpoints the fix immediately.

---

## Quick reference

| I want to...                          | Do this                                                      |
|---------------------------------------|--------------------------------------------------------------|
| Load a new project (easy way)         | Drop its `.xml` in `C:\xml` → **Refresh**                    |
| Load one exact file                   | Edit Parameters → `XML_Folder` = full `...\file.xml` path    |
| Use a different folder per project    | Edit Parameters → `XML_Folder` = that folder path            |
| Change the rate                       | Edit Parameters → `BlendedRate` = new number → **Refresh**   |
| See actuals                           | Export a **progressed** schedule from P6 (baseline shows 0)  |
