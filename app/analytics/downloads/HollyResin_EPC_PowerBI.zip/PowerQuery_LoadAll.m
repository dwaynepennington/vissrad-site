// ======================================================================
//  PowerQuery_LoadAll.m
//  One-shot loader for the Holly Resin EPC dashboard data model.
//
//  HOW TO USE (Power BI Desktop):
//    1. Home > Transform data  (opens Power Query Editor)
//    2. Home > New Source > Blank Query
//    3. View > Advanced Editor  -> delete everything, paste the
//       "XER_Folder" parameter block below (Step A), click Done.
//       Rename the query to:  XER_Folder
//    4. Repeat New Source > Blank Query + Advanced Editor for EACH table
//       block below (Step B). Rename each query to the table name shown.
//    5. Home > Close & Apply.
//
//  Simpler alternative: Home > Get Data > Text/CSV, import each of the 7
//  CSVs from the data folder, and skip this file entirely. The column
//  types are already clean.
// ======================================================================


// ---------- STEP A : the folder parameter (query name: XER_Folder) ----------
// Change the path to wherever your data folder lives.
"C:\P6_Dashboard\data"


// ======================================================================
// STEP B : one query per table. Each block is a complete M query.
// Create a Blank Query, paste ONE block, rename to the // name shown.
// ======================================================================


// name: fact_activities
let
    Source = Csv.Document(File.Contents(XER_Folder & "\fact_activities.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"task_id", type text}, {"activity_id", type text}, {"activity_name", type text},
        {"wbs_id", type text}, {"status", type text}, {"activity_kind", type text},
        {"is_milestone", type text}, {"is_critical", type text}, {"discipline", type text},
        {"phase", type text}, {"activity_type_code", type text},
        {"start_date", type date}, {"finish_date", type date},
        {"duration_days", type number}, {"total_float_days", type number},
        {"phys_complete_pct", type number}, {"man_hours", type number}, {"cost", type number},
        {"start_year", Int64.Type}, {"start_month", type text},
        {"finish_year", Int64.Type}, {"finish_month", type text}})
in
    Typed


// name: fact_manhours_monthly
let
    Source = Csv.Document(File.Contents(XER_Folder & "\fact_manhours_monthly.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"task_id", type text}, {"month", type date}, {"discipline", type text},
        {"phase", type text}, {"man_hours", type number}})
in
    Typed


// name: fact_assignments
let
    Source = Csv.Document(File.Contents(XER_Folder & "\fact_assignments.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"task_id", type text}, {"rsrc_id", type text},
        {"man_hours", type number}, {"cost", type number}})
in
    Typed


// name: dim_wbs
let
    Source = Csv.Document(File.Contents(XER_Folder & "\dim_wbs.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"wbs_id", type text}, {"wbs_short_name", type text}, {"wbs_name", type text},
        {"parent_wbs_id", type text}, {"wbs_level", Int64.Type},
        {"wbs_l1", type text}, {"wbs_l2", type text}, {"wbs_l3", type text},
        {"wbs_l4", type text}, {"wbs_l5", type text}})
in
    Typed


// name: dim_resource
let
    Source = Csv.Document(File.Contents(XER_Folder & "\dim_resource.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"rsrc_id", type text}, {"rsrc_short_name", type text},
        {"rsrc_name", type text}, {"rsrc_type", type text}})
in
    Typed


// name: dim_date
let
    Source = Csv.Document(File.Contents(XER_Folder & "\dim_date.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"month", type date}, {"year", Int64.Type}, {"month_name", type text},
        {"month_num", Int64.Type}, {"quarter", type text}})
in
    Typed


// name: dim_project
let
    Source = Csv.Document(File.Contents(XER_Folder & "\dim_project.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"project_name", type text}, {"project_short", type text},
        {"data_date", type date}, {"plan_start", type date}, {"planned_finish", type date},
        {"total_activities", Int64.Type}, {"total_relationships", Int64.Type},
        {"total_wbs_nodes", Int64.Type}, {"total_man_hours", type number}})
in
    Typed
