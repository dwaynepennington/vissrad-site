#!/usr/bin/env python3
"""
Convert-XER.py  —  Primavera P6 XER  ->  Power BI data model (CSV star-schema)

REUSABLE: point this at ANY P6 XER export and it produces the exact same set of
CSV files that the ResinPlant_EPC_Dashboard.pbit template expects. Refresh the
template and your dashboard updates.

USAGE
    python Convert-XER.py  <path-to.xer>  [output_folder]

    - If output_folder is omitted, CSVs are written to a "data" subfolder next
      to this script (this is the default folder the .pbit points at).

The output always contains these tables (stable column names):
    fact_activities, fact_manhours_monthly, fact_assignments,
    dim_wbs, dim_resource, dim_date, dim_project
"""
import csv, os, sys, datetime
from collections import defaultdict

# ======================================================================
#  OPTIONAL: blended labor rates ($/hour) to derive cost when the XER
#  has no dollar rates loaded (target_cost = 0). Leave RATE_PER_HOUR = 0
#  to keep cost as-loaded from the XER.
#    - Set a single blended rate, e.g. RATE_PER_HOUR = 95.0
#    - OR set per-discipline rates in DISCIPLINE_RATES (overrides blended).
#  Cost = man_hours * rate. Re-run the converter and Refresh Power BI.
# ======================================================================
RATE_PER_HOUR = 95.0          # blended labor rate ($/hr)
DISCIPLINE_RATES = {         # e.g. {"Piping": 88.0, "Electrical": 102.0}
}
# ======================================================================

# ----------------------------------------------------------------------
def parse_xer(path):
    tables, cur, fields = {}, None, None
    with open(path, "r", encoding="cp1252", errors="replace") as f:
        for line in f:
            line = line.rstrip("\r\n")
            if not line:
                continue
            p = line.split("\t")
            if p[0] == "%T":
                cur = p[1]; fields = None
                tables[cur] = {"fields": [], "rows": []}
            elif p[0] == "%F":
                fields = p[1:]; tables[cur]["fields"] = fields
            elif p[0] == "%R":
                v = p[1:]
                if fields:
                    if len(v) < len(fields): v += [""] * (len(fields) - len(v))
                    elif len(v) > len(fields): v = v[:len(fields)]
                tables[cur]["rows"].append(v)
    # to list-of-dicts
    out = {}
    for name, t in tables.items():
        if not t["fields"]:
            out[name] = []
            continue
        out[name] = [dict(zip(t["fields"], r)) for r in t["rows"]]
    return out

def pdate(s):
    if not s or not s.strip(): return None
    s = s.strip()
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try: return datetime.datetime.strptime(s, fmt)
        except ValueError: pass
    return None

def dstr(dt): return dt.strftime("%Y-%m-%d") if dt else ""
def num(s):
    try: return float(s)
    except (ValueError, TypeError): return 0.0

def month_iter(d1, d2):
    cur = datetime.date(d1.year, d1.month, 1)
    end = datetime.date(d2.year, d2.month, 1)
    while cur <= end:
        yield cur
        cur = datetime.date(cur.year + (cur.month // 12), (cur.month % 12) + 1, 1)

# ----------------------------------------------------------------------
def build(xer_path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    T = parse_xer(xer_path)

    tasks    = T.get("TASK", [])
    wbs      = T.get("PROJWBS", [])
    taskactv = T.get("TASKACTV", [])
    actvcode = T.get("ACTVCODE", [])
    actvtype = T.get("ACTVTYPE", [])
    taskrsrc = T.get("TASKRSRC", [])
    rsrc     = T.get("RSRC", [])
    taskpred = T.get("TASKPRED", [])
    project  = (T.get("PROJECT", []) or [{}])[0]

    proj_start  = pdate(project.get("plan_start_date"))
    proj_finish = pdate(project.get("scd_end_date")) or pdate(project.get("plan_end_date"))
    data_date   = pdate(project.get("last_recalc_date")) or proj_start

    # ---- activity code maps ----
    type_by_id = {a["actv_code_type_id"]: a["actv_code_type"] for a in actvtype}
    code_by_id = {c["actv_code_id"]: {"type": type_by_id.get(c["actv_code_type_id"], ""),
                                      "name": c["actv_code_name"]} for c in actvcode}
    task_codes = defaultdict(dict)
    for ta in taskactv:
        info = code_by_id.get(ta["actv_code_id"])
        if not info: continue
        t = info["type"].lower()
        if "discipline" in t:       task_codes[ta["task_id"]]["Discipline"] = info["name"]
        elif "phase" in t:          task_codes[ta["task_id"]]["Phase"] = info["name"]
        elif "activity type" in t:  task_codes[ta["task_id"]]["ActivityType"] = info["name"]

    # ---- WBS hierarchy ----
    wbs_by_id = {w["wbs_id"]: w for w in wbs}
    def wbs_path(wid):
        names, cur, seen = [], wid, set()
        while cur and cur in wbs_by_id and cur not in seen:
            seen.add(cur); w = wbs_by_id[cur]
            names.append(w["wbs_name"]); cur = w["parent_wbs_id"]
        return list(reversed(names))
    wbs_rows = []
    for w in wbs:
        path = wbs_path(w["wbs_id"]); lvls = (path + [""] * 5)[:5]
        wbs_rows.append({"wbs_id": w["wbs_id"], "wbs_short_name": w["wbs_short_name"],
            "wbs_name": w["wbs_name"], "parent_wbs_id": w["parent_wbs_id"],
            "wbs_level": len([p for p in path if p]),
            "wbs_l1": lvls[0], "wbs_l2": lvls[1], "wbs_l3": lvls[2],
            "wbs_l4": lvls[3], "wbs_l5": lvls[4]})

    # ---- man-hours / cost per task ----
    task_mh, task_cost = defaultdict(float), defaultdict(float)
    for tr in taskrsrc:
        task_mh[tr["task_id"]]   += num(tr.get("target_qty"))
        task_cost[tr["task_id"]] += num(tr.get("target_cost"))

    def _derive_cost(tid, disc):
        base = task_cost.get(tid, 0.0)
        if base > 0:
            return base
        mh = task_mh.get(tid, 0.0)
        rate = DISCIPLINE_RATES.get(disc, RATE_PER_HOUR)
        return mh * rate

    # ---- fact_activities ----
    tmap = {"TT_Task":"Task","TT_Mile":"Start Milestone","TT_FinMile":"Finish Milestone","TT_LOE":"Level of Effort"}
    smap = {"TK_NotStart":"Not Started","TK_Active":"In Progress","TK_Complete":"Complete"}
    acts = []
    for t in tasks:
        tid = t["task_id"]
        start  = pdate(t.get("target_start_date")) or pdate(t.get("act_start_date")) or pdate(t.get("early_start_date"))
        finish = pdate(t.get("target_end_date"))   or pdate(t.get("act_end_date"))   or pdate(t.get("early_end_date"))
        dur = round(num(t.get("target_drtn_hr_cnt"))/8.0, 1)
        tf  = round(num(t.get("total_float_hr_cnt"))/8.0, 1)
        c = task_codes.get(tid, {})
        acts.append({"task_id": tid, "activity_id": t.get("task_code"),
            "activity_name": t.get("task_name"), "wbs_id": t.get("wbs_id"),
            "status": smap.get(t.get("status_code"), t.get("status_code")),
            "activity_kind": tmap.get(t.get("task_type"), t.get("task_type")),
            "is_milestone": "Yes" if t.get("task_type") in ("TT_Mile","TT_FinMile") else "No",
            "is_critical": "Yes" if tf <= 0 else "No",
            "discipline": c.get("Discipline","(none)"), "phase": c.get("Phase","(none)"),
            "activity_type_code": c.get("ActivityType","(none)"),
            "start_date": dstr(start), "finish_date": dstr(finish),
            "duration_days": dur, "total_float_days": tf,
            "phys_complete_pct": num(t.get("phys_complete_pct")),
            "man_hours": round(task_mh.get(tid,0.0),1),
            "cost": round(_derive_cost(tid, c.get("Discipline","(none)")),2),
            "start_year": start.year if start else "", "start_month": start.strftime("%Y-%m") if start else "",
            "finish_year": finish.year if finish else "", "finish_month": finish.strftime("%Y-%m") if finish else ""})

    # ---- fact_manhours_monthly (spread evenly by month) ----
    spread = []
    for t in tasks:
        tid = t["task_id"]; mh = task_mh.get(tid, 0.0)
        if mh <= 0: continue
        start  = pdate(t.get("target_start_date")) or pdate(t.get("early_start_date"))
        finish = pdate(t.get("target_end_date"))   or pdate(t.get("early_end_date"))
        if not start or not finish or finish < start: continue
        months = list(month_iter(start.date(), finish.date()))
        per = mh / len(months) if months else mh
        c = task_codes.get(tid, {})
        for m in months:
            spread.append({"task_id": tid, "month": m.strftime("%Y-%m-01"),
                "discipline": c.get("Discipline","(none)"), "phase": c.get("Phase","(none)"),
                "man_hours": round(per,2)})

    # ---- fact_assignments ----
    assigns = []
    for tr in taskrsrc:
        a_mh = num(tr.get("target_qty"))
        a_cost = num(tr.get("target_cost"))
        if a_cost == 0 and (RATE_PER_HOUR or DISCIPLINE_RATES):
            a_cost = a_mh * RATE_PER_HOUR
        assigns.append({"task_id": tr["task_id"], "rsrc_id": tr.get("rsrc_id"),
                        "man_hours": round(a_mh,1), "cost": round(a_cost,2)})

    # ---- dim_resource ----
    rsrc_rows = [{"rsrc_id": r["rsrc_id"], "rsrc_short_name": r.get("rsrc_short_name"),
                  "rsrc_name": r.get("rsrc_name"), "rsrc_type": r.get("rsrc_type","").replace("RT_","")}
                 for r in rsrc]

    # ---- dim_date ----
    date_rows = []
    if proj_start and proj_finish:
        for m in month_iter(proj_start.date(), proj_finish.date()):
            date_rows.append({"month": m.strftime("%Y-%m-01"), "year": m.year,
                "month_name": m.strftime("%b %Y"), "month_num": m.month,
                "quarter": f"{m.year}-Q{(m.month-1)//3+1}"})

    # ---- dim_project ----
    proj_meta = [{"project_name": project.get("proj_short_name","P6 Project"),
        "project_short": project.get("proj_short_name"), "data_date": dstr(data_date),
        "plan_start": dstr(proj_start), "planned_finish": dstr(proj_finish),
        "total_activities": len(acts), "total_relationships": len(taskpred),
        "total_wbs_nodes": len(wbs_rows), "total_man_hours": round(sum(task_mh.values()),0)}]

    def write(name, rows):
        path = os.path.join(out_dir, f"{name}.csv")
        if not rows:
            # still write header-only so refresh doesn't fail
            open(path, "w").close(); print(f"  {name}: 0 rows (empty)"); return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        print(f"  {name}: {len(rows)} rows")

    print(f"Converting: {os.path.basename(xer_path)}")
    print(f"Output    : {out_dir}\n")
    write("fact_activities", acts)
    write("fact_manhours_monthly", spread)
    write("fact_assignments", assigns)
    write("dim_wbs", wbs_rows)
    write("dim_resource", rsrc_rows)
    write("dim_date", date_rows)
    write("dim_project", proj_meta)
    print(f"\nDone. {len(acts)} activities · {round(sum(task_mh.values())):,} man-hours")
    print("Open the .pbit (or Refresh if already open) and point XER_Folder at:")
    print(f"   {out_dir}")

# ----------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    xer = sys.argv[1]
    if not os.path.isfile(xer):
        print("ERROR: file not found:", xer); sys.exit(1)
    here = os.path.dirname(os.path.abspath(__file__))
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "data")
    build(xer, out)
