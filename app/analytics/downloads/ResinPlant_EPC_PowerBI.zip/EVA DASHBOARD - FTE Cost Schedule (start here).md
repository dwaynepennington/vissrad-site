# START HERE — FTE / Schedule / Cost Dashboard

This is your main dashboard. It shows **FTEs over time, a schedule Gantt, and
cost (budget / committed / forecast)** — and you can filter every page by
contractor or leave it on the total.

You point it at a P6 XML export and hit Refresh. That's it.

---

## Open it in 4 steps

**1. Turn on the .pbip setting (one time only)**
In Power BI Desktop: **File → Options → Preview features →** tick
**"Power BI Project (.pbip) save option" → OK → close and reopen Power BI.**

**2. Open the file**
`ResinPlantEPC_EVA_PBIP` folder → double-click **`ResinPlantEPC_EVA.pbip`**

**3. Tell it where your XML is**
Click **Home → Transform data → Edit Parameters**, then fill in:

| Parameter | What to type | Example |
|---|---|---|
| **XML_Folder** | The folder your XML is in, OR the full file path | `C:\xml`  or  `C:\xml\P6 XML TEST.xml` |
| **BlendedRate** | Your $/hour rate | `95` |

Type the path **without quotes**. Click **OK**.

**4. Refresh**
Click **Home → Refresh.** The whole dashboard fills in.

---

## To reuse it on a future project

1. Export the schedule from P6: **File → Export → Primavera PM - (XML)**.
2. Put that XML file in your folder (or point `XML_Folder` at wherever it is).
3. **Refresh.** Done — same dashboard, new project.

Change **BlendedRate** anytime to re-price everything instantly.

---

## The 3 main pages (first 3 tabs)

- **FTE Over Time** — headcount (FTEs) per month: Plan, Forecast, and Actual.
- **Schedule Status Gantt** — activities with planned dates and % complete.
- **Cost** — Budget vs Committed vs Forecast, by contractor.

Each page has two filters on the left:
- **Contractor Type** — Subcontractor / Self-Perform / Direct-Engineering
- **Discipline / Contractor** — the individual line (Civil, Piping, Paint, etc.)

Leave both empty = whole project total. Pick one = filtered view.

(Seven more detailed pages follow after these three.)

---

## Two things that are normal (not errors)

**1. "Actual" and "Committed" show zero.**
Your current export is a baseline — nothing has been worked yet, so there are no
actuals. The dashboard is already built to show them. As soon as you load a
**progressed** schedule (one with actual hours and dates), the Actual and
Committed numbers fill in automatically. No rebuild needed.

**2. Discipline and Phase on some pages say "(none)".**
That only fills in if your P6 export includes activity code assignments. The
contractor filters on the 3 main pages work regardless — those come from the
resource list, which is already complete.

---

## If Refresh gives an error

**"Illegal characters in path" or "can't find the file":**
- Make sure you typed the path with **no quotes** — `C:\xml`, not `"C:\xml"`.
- You can use either the **folder** (`C:\xml`) or the **full file path**
  (`C:\xml\P6 XML TEST.xml`) — both work.
- Double-check the folder/file actually exists at that spot.

If it still fails, send me the exact error text and I'll fix it.

---

## Numbers from your test file (so you can sanity-check)

| | |
|---|---|
| Total man-hours | 572,975 |
| Total cost @ $95 | $54,432,606 |
| Peak headcount | about 215 FTE (April 2027) |
| Schedule length | 27 months |
| Self-Perform / Direct / Sub | $31.3M / $18.8M / $4.3M |
