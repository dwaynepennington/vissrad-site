@echo off
REM ============================================================
REM  Update-Dashboard.bat
REM  Drag-and-drop a P6 .xer file onto this icon (or run it and
REM  it will use the most recent .xer in this folder) to refresh
REM  the Power BI data model.
REM ============================================================
setlocal
cd /d "%~dp0"

set "XER=%~1"

if "%XER%"=="" (
    echo No file dropped. Looking for the newest .xer in this folder...
    for /f "delims=" %%F in ('dir /b /o-d *.xer 2^>nul') do (
        set "XER=%%F"
        goto :found
    )
    echo.
    echo   No .xer file found. Drag a .xer onto this .bat, or place one
    echo   in this folder and run again.
    echo.
    pause
    exit /b 1
)
:found

echo.
echo Converting "%XER%" ...
echo.

REM Try python, then py launcher
where python >nul 2>nul
if %errorlevel%==0 (
    python "%~dp0Convert-XER.py" "%XER%"
) else (
    py "%~dp0Convert-XER.py" "%XER%"
)

echo.
echo ------------------------------------------------------------
echo  Done. Now open ResinPlant_EPC_Dashboard.pbit (or click
echo  Refresh in Power BI if it is already open).
echo ------------------------------------------------------------
echo.
pause
