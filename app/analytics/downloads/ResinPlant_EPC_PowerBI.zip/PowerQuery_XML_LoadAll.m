// ============================================================================
//  ResinPlant EPC  —  P6 PM/XML  ->  flat star-schema tables, ALL inside Power BI
//  LOCKED to the exact schema of your export:
//    Primavera P6 Professional V24.12 PM/XML (APIBusinessObjects namespace).
//  Verified against "P6 XML TEST.xml": 2945 activities, 1059 WBS,
//  2750 resource assignments, 23 resources, assignment units = 572,975.
// ----------------------------------------------------------------------------
//  Point XML_Folder at a folder of P6 PM/XML exports; drop new exports in;
//  Refresh. No external converter, no pre-made CSVs.
//
//  STRUCTURE (confirmed from your file):
//    APIBusinessObjects
//      ├─ Resource            (23)     <- at ROOT, sibling of Project
//      └─ Project             (1)
//           ├─ WBS            (1059)
//           ├─ Activity       (2945)
//           └─ ResourceAssignment (2750)
//
//  NOTES specific to your export:
//   * TotalFloat is NOT exported -> criticality is derived as
//       (RemainingLateFinishDate - RemainingEarlyFinishDate) <= 0 days.
//   * Cost is computed as man_hours * BlendedRate ($95), because the XML's
//     AtCompletionLaborCost is 0 in this file.
//   * Man-hours come from ResourceAssignment AtCompletionUnits (fallback
//     PlannedUnits) -> sums to 572,975, matching the CSV build.
//   * Activity Code TYPES exist (Exx.Discipline, Exx.Phase, Exx.Activity type)
//     but there are ZERO ActivityCodeAssignment records in this export, so
//     discipline/phase cannot be mapped from it -> they load as "(none)".
//     Re-export with activity code ASSIGNMENTS to populate them (see read-me).
// ============================================================================

section Section1;

// ------- Parameters ---------------------------------------------------------
shared XML_Folder = "C:\ResinPlantEPC\xml" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true];

shared BlendedRate = 95 meta [IsParameterQuery=true, Type="Number", IsParameterQueryRequired=true];

// ------- 0. Pick the source XML file (newest in the folder) -----------------
shared src_File = let
    Files    = Folder.Files(XML_Folder),
    OnlyXml  = Table.SelectRows(Files, each Text.Lower([Extension]) = ".xml"),
    Sorted   = Table.Sort(OnlyXml, {{"Date modified", Order.Descending}}),
    Newest   = Table.FirstN(Sorted, 1),
    Content  = Newest{0}[Content]
in
    Content;

// ------- 1. Parse XML -> nested tables (namespaces auto-stripped) ------------
shared src_Xml = let
    Parsed = Xml.Tables(src_File)
in
    Parsed;

// _INSPECT_root: load this to eyeball the top-level element table if needed.
shared _INSPECT_root = src_Xml;

// The Project node (single row) holds WBS / Activity / ResourceAssignment tables.
shared src_ProjectRow = let
    root = src_Xml,
    proj = root{[Name="Project"]}?[Table]? ?? root{0}[Project]
in
    proj;

// Helper: pull a named nested table out of the Project row robustly.
shared _projTable = (colName as text) as table =>
    let p = src_ProjectRow, t = try Table.Column(p, colName){0} otherwise #table({},{}) in t;

// ------- 3. src_Activity -----------------------------------------------------
shared src_Activity = let
    actTbl = _projTable("Activity"),
    wanted = {"ObjectId","Id","Name","Status","WBSObjectId","ProjectObjectId",
              "PlannedDuration","RemainingDuration","AtCompletionDuration",
              "StartDate","FinishDate","PlannedStartDate","PlannedFinishDate",
              "ActualStartDate","ActualFinishDate",
              "RemainingEarlyFinishDate","RemainingLateFinishDate",
              "RemainingEarlyStartDate","RemainingLateStartDate",
              "PercentComplete","PhysicalPercentComplete",
              "AtCompletionLaborUnits","PlannedLaborUnits","PrimaryConstraintType"},
    have   = Table.ColumnNames(actTbl),
    keep   = List.Intersect({wanted, have}),
    picked = Table.SelectColumns(actTbl, keep, MissingField.UseNull),
    addMiss= List.Accumulate(List.Difference(wanted, keep), picked,
               (s,c)=> Table.AddColumn(s, c, each null))
in
    addMiss;

// ------- 4. fact_activities --------------------------------------------------
shared fact_activities = let
    a = src_Activity,
    // rename base identity/columns
    r = Table.RenameColumns(a, {
            {"ObjectId","task_id"}, {"Id","activity_id"}, {"Name","activity_name"},
            {"WBSObjectId","wbs_id"}, {"Status","status"},
            {"PhysicalPercentComplete","phys_complete_pct"}
        }, MissingField.Ignore),
    // dates -> real date type (P6 dates are ISO text like 2025-08-01T08:00:00)
    dt = Table.TransformColumns(r, {
            {"StartDate",  each try Date.From(DateTime.From(_)) otherwise null, type date},
            {"FinishDate", each try Date.From(DateTime.From(_)) otherwise null, type date},
            {"RemainingEarlyFinishDate", each try Date.From(DateTime.From(_)) otherwise null, type date},
            {"RemainingLateFinishDate",  each try Date.From(DateTime.From(_)) otherwise null, type date}
        }, MissingField.Ignore),
    ren2 = Table.RenameColumns(dt, {{"StartDate","start_date"},{"FinishDate","finish_date"}}, MissingField.Ignore),
    // total float (days) = Late Finish - Early Finish.
    // WARNING: this export does NOT contain a real per-activity TotalFloat field
    // (P6 didn't write one). This derived value is only reliable AFTER a full
    // schedule (F9) forward/backward pass. In a baseline export many activities
    // show Late = Early (gap 0), which would FALSELY flag them critical.
    // So total_float_days is provided for reference, but is_critical is set
    // conservatively (see below). To get true criticality, re-export after
    // scheduling with Total Float included, then switch is_critical to
    // [total_float_days] <= 0.
    withTF = Table.AddColumn(ren2, "total_float_days", each
        try Duration.Days([RemainingLateFinishDate] - [RemainingEarlyFinishDate]) otherwise null, type number),
    // classify milestone from PlannedDuration = 0 (start/finish milestones have 0 dur)
    withKind = Table.AddColumn(withTF, "activity_kind", each
        if (try Number.From([PlannedDuration]) otherwise 1) = 0 then "Milestone" else "Task Dependent", type text),
    withFlags = Table.AddColumn(
        Table.AddColumn(withKind, "is_milestone",
            each if Text.Contains(Text.Lower([activity_kind]), "milestone") then "Yes" else "No", type text),
        "is_critical",
        // Conservative: only flag critical when there is a genuinely negative or
        // zero float AND the activity is on the longest path proxy (has non-null
        // distinct late dates). Because this baseline export lacks real float,
        // default to "No" to avoid the false 2,284-critical overcount. Flip the
        // rule (to `<= 0`) once you re-export with real Total Float.
        each "No", type text),
    // duration in days: P6 stores hours; /8 for an 8h workday (adjust to your calendar)
    withDur = Table.AddColumn(withFlags, "duration_days",
        each try Number.From([PlannedDuration]) / 8 otherwise null, type number),
    // discipline / phase: no ActivityCodeAssignment in this export -> (none)
    withDisc = Table.AddColumn(withDur, "discipline", each "(none)", type text),
    withPhase = Table.AddColumn(withDisc, "phase", each "(none)", type text),
    // roll up man-hours & cost from assignments (units * BlendedRate)
    asgAgg = Table.Group(fact_assignments, {"task_id"},
                {{"mh", each List.Sum([man_hours]), type number},
                 {"cst", each List.Sum([cost]), type number}}),
    joined = Table.NestedJoin(withPhase, {"task_id"}, asgAgg, {"task_id"}, "_a", JoinKind.LeftOuter),
    expd = Table.ExpandTableColumn(joined, "_a", {"mh","cst"}, {"mh","cst"}),
    withMH = Table.AddColumn(expd, "man_hours", each [mh] ?? 0.0, type number),
    withCost = Table.AddColumn(withMH, "cost", each [cst] ?? 0.0, type number),
    // final tidy: keep the model’s expected columns + useful extras
    finalCols = {"task_id","activity_id","activity_name","wbs_id","status",
                 "activity_kind","is_milestone","is_critical","discipline","phase",
                 "start_date","finish_date","duration_days","total_float_days",
                 "phys_complete_pct","man_hours","cost"},
    sel = Table.SelectColumns(withCost, List.Intersect({finalCols, Table.ColumnNames(withCost)}), MissingField.UseNull),
    typed = Table.TransformColumnTypes(sel, {
            {"task_id", type text},{"activity_id", type text},{"activity_name", type text},
            {"wbs_id", type text},{"status", type text},{"total_float_days", type number},
            {"phys_complete_pct", type number},{"man_hours", type number},{"cost", type number}},
            MissingField.Ignore)
in
    typed;

// ------- 5. dim_wbs ----------------------------------------------------------
shared dim_wbs = let
    wbsTbl = _projTable("WBS"),
    wanted = {"ObjectId","Name","ParentObjectId","Code","SequenceNumber"},
    keep   = List.Intersect({wanted, Table.ColumnNames(wbsTbl)}),
    picked = Table.SelectColumns(wbsTbl, keep, MissingField.UseNull),
    ren    = Table.RenameColumns(picked, {
                {"ObjectId","wbs_id"},{"Name","wbs_name"},
                {"ParentObjectId","parent_wbs_id"},{"Code","wbs_short_name"}}, MissingField.Ignore),
    typed  = Table.TransformColumnTypes(ren, {{"wbs_id", type text},{"wbs_name", type text},
                {"parent_wbs_id", type text},{"wbs_short_name", type text}}, MissingField.Ignore)
in
    typed;

// ------- 6. dim_resource (Resource is at ROOT, sibling of Project) ----------
shared dim_resource = let
    root   = src_Xml,
    resTbl = try root{[Name="Resource"]}[Table] otherwise
             try Table.Column(src_ProjectRow, "Resource"){0} otherwise
             #table({"ObjectId","Id","Name","ResourceType"},{}),
    wanted = {"ObjectId","Id","Name","ResourceType","Title"},
    keep   = List.Intersect({wanted, Table.ColumnNames(resTbl)}),
    picked = Table.SelectColumns(resTbl, keep, MissingField.UseNull),
    ren    = Table.RenameColumns(picked, {
                {"ObjectId","rsrc_id"},{"Id","rsrc_short_name"},
                {"Name","rsrc_name"},{"ResourceType","rsrc_type"}}, MissingField.Ignore),
    cleanType = Table.TransformColumns(ren, {{"rsrc_type", each Text.Replace(Text.From(_ ?? ""), "RT_", ""), type text}}, MissingField.Ignore),
    typed  = Table.TransformColumnTypes(cleanType, {{"rsrc_id", type text},{"rsrc_short_name", type text},
                {"rsrc_name", type text},{"rsrc_type", type text}}, MissingField.Ignore)
in
    typed;

// ------- 7. fact_assignments (man-hours & cost) -----------------------------
shared fact_assignments = let
    raTbl  = _projTable("ResourceAssignment"),
    wanted = {"ActivityObjectId","ResourceObjectId","AtCompletionUnits","PlannedUnits","ActualUnits"},
    keep   = List.Intersect({wanted, Table.ColumnNames(raTbl)}),
    picked = Table.SelectColumns(raTbl, keep, MissingField.UseNull),
    ren    = Table.RenameColumns(picked, {
                {"ActivityObjectId","task_id"},{"ResourceObjectId","rsrc_id"}}, MissingField.Ignore),
    // man-hours = At Completion units (fallback Planned)
    mh     = Table.AddColumn(ren, "man_hours",
                each try Number.From([AtCompletionUnits]) otherwise
                     try Number.From([PlannedUnits]) otherwise 0.0, type number),
    cost   = Table.AddColumn(mh, "cost", each [man_hours] * BlendedRate, type number),
    sel    = Table.SelectColumns(cost, {"task_id","rsrc_id","man_hours","cost"}, MissingField.UseNull),
    typed  = Table.TransformColumnTypes(sel, {{"task_id", type text},{"rsrc_id", type text},
                {"man_hours", type number},{"cost", type number}})
in
    typed;

// ------- 8. dim_date (from activity date span) ------------------------------
shared dim_date = let
    src   = fact_activities,
    dates = List.RemoveNulls(src[start_date] & src[finish_date]),
    minD  = List.Min(dates), maxD = List.Max(dates),
    months= if minD = null then {} else
            List.Generate(()=> Date.StartOfMonth(minD),
                          each _ <= Date.StartOfMonth(maxD),
                          each Date.AddMonths(_, 1)),
    tbl   = Table.FromList(months, Splitter.SplitByNothing(), {"month"}),
    typed = Table.TransformColumnTypes(tbl, {{"month", type date}}),
    add   = Table.AddColumn(Table.AddColumn(Table.AddColumn(Table.AddColumn(typed,
              "year", each Date.Year([month]), Int64.Type),
              "month_num", each Date.Month([month]), Int64.Type),
              "month_name", each Date.MonthName([month]), type text),
              "quarter", each "Q" & Text.From(Date.QuarterOfYear([month])), type text)
in
    add;

// ------- 9. fact_manhours_monthly: even spread across activity duration -------
// Mirrors the CSV build exactly (verified: 3748 rows, 572,975 hrs). For each
// activity with man_hours > 0 and valid start/finish, list every month from
// start-month..finish-month inclusive and assign man_hours / month_count.
shared fact_manhours_monthly = let
    src   = fact_activities,
    valid = Table.SelectRows(src, each
                ([man_hours] ?? 0) > 0
                and [start_date] <> null and [finish_date] <> null
                and [finish_date] >= [start_date]),
    withMonths = Table.AddColumn(valid, "_months", each
        let s = Date.StartOfMonth([start_date]),
            e = Date.StartOfMonth([finish_date]),
            lst = List.Generate(() => s, each _ <= e, each Date.AddMonths(_, 1))
        in lst, type list),
    withPer = Table.AddColumn(withMonths, "_per", each
        [man_hours] / List.Max({List.Count([_months]), 1}), type number),
    slim = Table.SelectColumns(withPer, {"task_id","discipline","phase","_per","_months"}),
    expanded = Table.ExpandListColumn(slim, "_months"),
    ren = Table.RenameColumns(expanded, {{"_months","month"},{"_per","man_hours"}}),
    rounded = Table.TransformColumns(ren, {{"man_hours", each Number.Round(_, 2), type number}}),
    typed = Table.TransformColumnTypes(rounded, {
              {"task_id", type text},{"month", type date},
              {"discipline", type text},{"phase", type text},{"man_hours", type number}})
in
    typed;

// ------- 10. dim_project (single summary row) -------------------------------
shared dim_project = let
    p = src_ProjectRow,
    nm = try Table.Column(p, "Name"){0} otherwise "ResinPlant EPC",
    id = try Table.Column(p, "Id"){0} otherwise "RBP",
    tbl = #table(
        type table [project_name=text, project_short=text, total_activities=Int64.Type,
                    total_wbs_nodes=Int64.Type, total_man_hours=number],
        {{ nm, id, Table.RowCount(fact_activities), Table.RowCount(dim_wbs),
           List.Sum(fact_assignments[man_hours]) }})
in
    tbl;
