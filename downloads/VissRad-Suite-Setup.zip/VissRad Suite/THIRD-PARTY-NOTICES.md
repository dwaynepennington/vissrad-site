# Third-party notices

VissRad is proprietary software of Pennington Group LLC (see `LICENSE`). It
includes or depends on the open-source components below. Each remains under its
own licence, and nothing in the VissRad licence limits the rights those licences
grant. Keep this file with every distributed copy.

| Component | Where it is used | Licence | Obligation |
|---|---|---|---|
| three.js | `web/vendor/three.min.js` (4D, AWP, commissioning model views) | MIT | Keep the copyright and licence notice in distributed copies |
| PDF.js (Mozilla) | `web/vendor/pdfjs/` (document viewer, VRMarkup) | Apache 2.0 | Keep `web/vendor/pdfjs/LICENSE`; note modifications, if any |
| pdf-lib 1.17.1 | `web/vendor/pdf-lib/` (VRMarkup: writes marked-up PDFs; Schedule Summary and Critical Path report, PDF) | MIT | Keep `web/vendor/pdf-lib/LICENSE` (also `LICENSE.md`) |
| PptxGenJS 4.0.1 (Brent Ely) | `web/vendor/pptxgenjs/` (VRSCH / VRScheduler: Schedule Summary and Critical Path report, PowerPoint) | MIT | Keep `web/vendor/pptxgenjs/LICENSE` |
| JSZip 3.10.1 (Stuart Knightley), bundled in `pptxgen.bundle.js` | `web/vendor/pptxgenjs/` | MIT (dual MIT / GPLv3; used under MIT) | Keep `web/vendor/pptxgenjs/JSZIP-LICENSE` |
| qrcode-generator 1.4.4 (Kazuhiko Arase) | `web/vendor/qrcode/` (VRCMMS QR asset labels) | MIT | Keep `web/vendor/qrcode/LICENSE` and the notice in `qrcode.js` |
| FastAPI | VissRad Server | MIT | Keep notice |
| Uvicorn | VissRad Server | BSD 3-Clause | Keep notice; no endorsement by contributors |
| segno | VissRad Server (QR codes) | BSD 3-Clause | Keep notice |
| PySide6 (Qt for Python) | Desktop applications | LGPL 3.0 | Ship PySide6/Qt as separate, replaceable libraries (not statically linked); include the LGPL text; do not prohibit reverse engineering of the Qt libraries themselves; offer Qt source on request |
| SQLAlchemy | Desktop applications | MIT | Keep notice |
| pyqtgraph | Desktop applications | MIT | Keep notice |
| openpyxl | Desktop applications, sample builders | MIT | Keep notice |
| ReportLab (open-source edition) | Desktop report output | BSD 3-Clause | Keep notice |

Fonts bundled for offline use (`installer/assets/fonts/`: Inter, Montserrat,
JetBrains Mono) are distributed under the SIL Open Font Licence 1.1; keep the
OFL text with the font files.

When a new dependency is added, add a row here before the next release.

## VRSmartPlan Cost Book data (shared/costbook/)

- **United States Construction Cost Database (USCCDB) v1.0**: Oga, T. (2026), https://doi.org/10.5281/zenodo.22979157. The compilation is licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Rows were filtered to public values, paired and regrouped, and their notes were rewritten in English. Values from U.S. federal sources are public domain (17 U.S.C. 105). NJDOT rows are reused under the open terms quoted in the USCCDB ledger.
- **State publications**: Caltrans equipment rental rates, NCDOT bid averages and Mississippi DOT production rates. No reuse restriction is stated.
- **EIA AEO Table 3 and DoD UFC 3-701-01 Tables 4-2 to 4-4**: U.S. federal, public domain.
- **Not included**: commercial cost-book values (RSMeans, Marshall & Swift, CostWorks, UFC Table 6), and Texas and Florida DOT data.
