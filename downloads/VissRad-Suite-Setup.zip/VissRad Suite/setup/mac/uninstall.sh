#!/bin/bash
# VissRad Suite - remove from this Mac.
#
# Removes the program and the apps in ~/Applications/VissRad Suite. Your saved
# records are kept unless you choose to delete them too.
#
#   uninstall.sh [--quiet] [--delete-records]

NAME="VissRad Suite"
ROOT="$HOME/Library/Application Support/$NAME"
DATA="$ROOT/profile"
APPS="$HOME/Applications/$NAME"
QUIET=0; DEL=0
for a in "$@"; do case "$a" in --quiet) QUIET=1 ;; --delete-records) DEL=1 ;; esac; done
say() { printf '  %s\n' "$*"; }
echo ""
echo "  VissRad Suite - remove"
echo "  --------------------"
if [ "$QUIET" = 0 ]; then
  printf '  Remove VissRad Suite from this Mac? Type Y to continue: '; read -r go
  case "$go" in [Yy]*) ;; *) say "Nothing was changed."; exit 0 ;; esac
  if [ "$DEL" = 0 ] && [ -d "$DATA" ]; then
    echo ""
    say "Your saved records are kept unless you delete them now."
    say "(Use File > Save file, or export your schedule, first if you need a copy.)"
    printf '  Type DELETE to remove your saved records too, or press Return to keep them: '; read -r del
    [ "$del" = "DELETE" ] && DEL=1
  fi
fi
# Close a running VissRad Suite window first.
pids="$(ps -axo pid=,command= | D="--user-data-dir=$DATA" awk 'index($0, ENVIRON["D"]) { print $1 }')"
[ -n "$pids" ] && { kill $pids 2>/dev/null; sleep 1; }
rm -rf "$APPS"
rm -rf "$ROOT/app" "$ROOT/setup" "$ROOT/VERSION.txt" "$ROOT/README.txt"
if [ "$DEL" = 1 ]; then
  rm -rf "$ROOT"
  say "VissRad Suite and your saved records have been removed."
else
  say "VissRad Suite has been removed. Your saved records are still in $DATA"
  say "and open again if you install VissRad Suite later."
fi
exit 0
