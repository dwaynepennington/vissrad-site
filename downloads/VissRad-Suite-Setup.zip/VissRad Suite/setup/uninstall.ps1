# VissRad Suite - remove from this computer.
#
# Removes the program, the Desktop icon, the Start menu entry and the
# Apps & features entry. Your saved schedules are kept unless you choose to
# delete them too. A taskbar pin, if you added one, is removed by Windows when
# its program goes; otherwise right-click it and choose Unpin from taskbar.

param([switch]$DeleteSchedules, [switch]$Quiet)

$Name = "VissRad Suite"
$Root = Join-Path $env:LOCALAPPDATA $Name
$DataDir = Join-Path $Root "profile"

function Say($text, $colour = "Gray") { Write-Host "  $text" -ForegroundColor $colour }

Write-Host ""
Write-Host "  VissRad Suite - remove" -ForegroundColor Cyan
Write-Host "  --------------------"

if (-not $Quiet) {
    $go = Read-Host "  Remove VissRad Suite from this computer? Type Y to continue"
    if ($go -notmatch '^\s*[Yy]') { Say "Nothing was changed." "Yellow"; Start-Sleep -Seconds 2; exit 0 }
    if (-not $DeleteSchedules -and (Test-Path -LiteralPath $DataDir)) {
        Write-Host ""
        Say "Your saved schedules are kept unless you delete them now." "White"
        Say "(Export anything you need to an .xer file first.)"
        $del = Read-Host "  Type DELETE to remove your saved schedules too, or press Enter to keep them"
        $DeleteSchedules = ($del -ceq "DELETE")
    }
}

# Close a running VissRad Suite window first.
try {
    Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction Stop |
        Where-Object { $_.CommandLine -and $_.CommandLine -like "*$DataDir*" } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
} catch { }

$desktop = [Environment]::GetFolderPath("Desktop")
$programs = Join-Path ([Environment]::GetFolderPath("Programs")) $Name
Remove-Item -LiteralPath (Join-Path $desktop "$Name.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $programs -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$Name" -Recurse -Force -ErrorAction SilentlyContinue

foreach ($f in @("app", "setup", "VERSION.txt", "README.txt")) {
    Remove-Item -LiteralPath (Join-Path $Root $f) -Recurse -Force -ErrorAction SilentlyContinue
}
if ($DeleteSchedules) {
    Remove-Item -LiteralPath $Root -Recurse -Force -ErrorAction SilentlyContinue
    Say "VissRad Suite and your saved schedules have been removed." "Green"
} else {
    Say "VissRad Suite has been removed. Your saved schedules are still in $DataDir" "Green"
    Say "and open again if you install VissRad Suite later."
}
if (-not $Quiet) { Start-Sleep -Seconds 4 }
exit 0
