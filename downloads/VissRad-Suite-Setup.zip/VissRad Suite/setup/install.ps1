# VissRad Suite setup (per user, no admin rights, nothing else to install).
#
# Copies VissRad Suite to %LOCALAPPDATA%\VissRad Suite\app, then creates a Desktop
# icon, a Start menu entry and an Apps & features entry. The icon opens
# VissRad Suite in its own window (Microsoft Edge, or Google Chrome, in app mode)
# with a private browser profile, so your schedules are kept apart from normal
# browsing and are not removed when the browser's history is cleared.
# Re-running setup updates the program and keeps your schedules.

param(
    [string]$Source = "",
    [switch]$NoLaunch,
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"
$Name = "VissRad Suite"

function Say($text, $colour = "Gray") { Write-Host "  $text" -ForegroundColor $colour }

if ([string]::IsNullOrWhiteSpace($Source)) { $Source = Split-Path -Parent $PSScriptRoot }
$Source = (Resolve-Path -LiteralPath $Source).Path.TrimEnd('\')
$Root = Join-Path $env:LOCALAPPDATA $Name
$App = Join-Path $Root "app"
$DataDir = Join-Path $Root "profile"   # browser profile: holds your schedules
$Setup = Join-Path $Root "setup"

Write-Host ""
Write-Host "  VissRad Suite - setup" -ForegroundColor Cyan
Write-Host "  -------------------"
$verFile = Join-Path $Source "VERSION.txt"
$version = ""
if (Test-Path -LiteralPath $verFile) {
    $version = ((Get-Content -LiteralPath $verFile | Where-Object { $_ -match '^version' } | Select-Object -First 1) -replace '^version\s*', '').Trim()
    Say "Version: $version"
}
Say "Installing to: $Root"
Write-Host ""

if (-not (Test-Path -LiteralPath (Join-Path $Source "app\index.html"))) {
    Say "The program files were not found next to this setup." "Red"
    Say "Extract the whole zip first (right-click it > Extract All), then run setup again." "Yellow"
    exit 1
}

# 1. Windows marks downloaded files; clear that so it does not warn on every file.
Say "Preparing files ..."
Get-ChildItem -LiteralPath $Source -Recurse -File -ErrorAction SilentlyContinue |
    Unblock-File -ErrorAction SilentlyContinue

# 2. Close a running VissRad Suite window so its files can be replaced.
function Stop-VRWindows {
    try {
        Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction Stop |
            Where-Object { $_.CommandLine -and $_.CommandLine -like "*$DataDir*" } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch { }
}
Stop-VRWindows

# 3. Copy the program. The profile folder (your schedules) is never touched.
if ($Source -ne $Root) {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    foreach ($dir in @($App, $Setup)) {
        if (Test-Path -LiteralPath $dir) { Remove-Item -LiteralPath $dir -Recurse -Force }
    }
    Say "Copying VissRad Suite ..."
    Copy-Item -LiteralPath (Join-Path $Source "app") -Destination $App -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $Source "setup") -Destination $Setup -Recurse -Force
    foreach ($f in @("VERSION.txt", "README.txt")) {
        $p = Join-Path $Source $f
        if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination $Root -Force }
    }
}
New-Item -ItemType Directory -Path $DataDir -Force | Out-Null

# 4. The browser that shows VissRad Suite (started with --allow-file-access-from-files so
#    VREstimator can read PDF drawings and run text recognition from these local
#    files; it applies only to this separate VissRad Suite window and profile): Microsoft Edge (part of Windows 10 and 11),
#    otherwise Google Chrome, otherwise the default browser.
function Find-Browser {
    $found = @()
    foreach ($exe in @("msedge.exe", "chrome.exe")) {
        foreach ($key in @(
            "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe",
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\$exe")) {
            try {
                $v = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).'(default)'
                if ($v) { $found += $v.Trim('"') }
            } catch { }
        }
        $sub = if ($exe -eq "msedge.exe") { "Microsoft\Edge\Application\msedge.exe" } else { "Google\Chrome\Application\chrome.exe" }
        foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA)) {
            if ($base) { $found += (Join-Path $base $sub) }
        }
    }
    foreach ($p in $found) { if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return $p } }
    return $null
}

$index = Join-Path $App "index.html"
$url = ([System.Uri]$index).AbsoluteUri
$icon = Join-Path $App "assets\vissrad.ico"
$browser = Find-Browser
if ($browser) {
    $target = $browser
    $arguments = "--app=`"$url`" --user-data-dir=`"$DataDir`" --allow-file-access-from-files --no-first-run --no-default-browser-check --start-maximized"
    Say ("Opens in: " + (Split-Path -Leaf $browser) + " (its own window)")
} else {
    $target = $index
    $arguments = ""
    Say "Microsoft Edge and Google Chrome were not found; VissRad Suite will open in your default browser." "Yellow"
}

# 5. Shortcuts: Desktop and Start menu.
$shell = New-Object -ComObject WScript.Shell
function New-Shortcut($path, $target, $arguments, $icon, $description, $workdir) {
    $sc = $shell.CreateShortcut($path)
    $sc.TargetPath = $target
    if ($arguments) { $sc.Arguments = $arguments }
    $sc.WorkingDirectory = $workdir
    $sc.Description = $description
    if ($icon -and (Test-Path -LiteralPath $icon)) { $sc.IconLocation = "$icon,0" }
    $sc.Save()
}

Say "Creating the Desktop icon and Start menu entries ..."
$desktop = [Environment]::GetFolderPath("Desktop")
$programs = Join-Path ([Environment]::GetFolderPath("Programs")) $Name
New-Item -ItemType Directory -Path $programs -Force | Out-Null
$desc = "VissRad Suite - every VissRad module, opening on your own projects"
New-Shortcut (Join-Path $desktop "$Name.lnk") $target $arguments $icon $desc $App
New-Shortcut (Join-Path $programs "$Name.lnk") $target $arguments $icon $desc $App
# The sibling tools (VREstimator, the planners, VRTAR and VRCMMS): Start menu entries in the same window profile,
# so an estimate or a plan can be sent to the VRScheduler Schedule Editor.
# The tool list is setup\tools.txt: one line per tool, "Name|folder|id|description".
$toolList = Join-Path $PSScriptRoot "tools.txt"
$tools = @()
if (Test-Path -LiteralPath $toolList) {
    foreach ($line in (Get-Content -LiteralPath $toolList -Encoding UTF8)) {
        if ($line.Trim() -and -not $line.StartsWith("#")) { $parts = $line.Split("|"); $tools += ,@($parts[0], $parts[1], $parts[3]) }
    }
}
foreach ($tool in $tools) {
    $page = Join-Path $App ($tool[1] + "\index.html")
    if (-not (Test-Path -LiteralPath $page)) { continue }
    $turl = ([System.Uri]$page).AbsoluteUri
    if ($browser) { $targs = "--app=`"$turl`" --user-data-dir=`"$DataDir`" --allow-file-access-from-files --no-first-run --no-default-browser-check --start-maximized"; $ttarget = $browser }
    else { $targs = ""; $ttarget = $page }
    New-Shortcut (Join-Path $programs ($tool[0] + ".lnk")) $ttarget $targs $icon $tool[2] $App
}

$ps = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
$uninstall = Join-Path $Setup "uninstall.ps1"
$unArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$uninstall`""
New-Shortcut (Join-Path $programs "Uninstall $Name.lnk") $ps $unArgs $null "Remove VissRad Suite from this computer" $env:TEMP

# 6. Apps & features entry (per user), so it can be removed like any program.
try {
    $reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$Name"
    New-Item -Path $reg -Force | Out-Null
    $kb = [int]((Get-ChildItem -LiteralPath $App -Recurse -File | Measure-Object -Property Length -Sum).Sum / 1KB)
    $values = @{
        DisplayName = $Name; DisplayVersion = $version; Publisher = "Pennington Group Associates (VissRad)"
        DisplayIcon = $icon; InstallLocation = $Root; URLInfoAbout = "https://vissrad.com/"
        UninstallString = "`"$ps`" $unArgs"
    }
    foreach ($k in $values.Keys) { New-ItemProperty -Path $reg -Name $k -Value $values[$k] -PropertyType String -Force | Out-Null }
    foreach ($k in @("NoModify", "NoRepair")) { New-ItemProperty -Path $reg -Name $k -Value 1 -PropertyType DWord -Force | Out-Null }
    New-ItemProperty -Path $reg -Name "EstimatedSize" -Value $kb -PropertyType DWord -Force | Out-Null
} catch {
    Say "Could not add the Apps & features entry; use Start menu > VissRad Suite > Uninstall VissRad Suite instead." "Yellow"
}

Write-Host ""
Say "VissRad Suite is installed." "Green"
Say "Start it from the VissRad Suite icon on your Desktop or in the Start menu."
Write-Host ""
Say "To keep it on the taskbar (Windows only allows you to do this yourself):" "White"
Say "  right-click the VissRad Suite icon on the Desktop and choose Pin to taskbar."
Say "  On Windows 11, choose Show more options first."
Write-Host ""
Say "Your schedules are kept on this computer, in $DataDir"
Say "Running setup again updates VissRad Suite and keeps them."
Write-Host ""

if (-not $NoLaunch) {
    Say "Opening VissRad Suite ..." "Cyan"
    if ($arguments) { Start-Process -FilePath $target -ArgumentList $arguments -WorkingDirectory $App }
    else { Start-Process -FilePath $target }
}
if (-not $Quiet) {
    Write-Host ""
    Read-Host "  Press Enter to close this window" | Out-Null
}
exit 0
