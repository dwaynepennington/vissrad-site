#!/bin/bash
# Double-click to install VissRad Suite on this Mac (no admin rights needed).
cd "$(dirname "$0")" || exit 1
bash "./setup/mac/install.sh" "$@"
