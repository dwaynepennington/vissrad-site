#!/bin/bash
# VRSmartPlan setup for macOS (per user, no admin rights, nothing else to install).
#
# Copies VRSmartPlan to ~/Library/Application Support/VRSmartPlan/app and puts
# an app for each tool in ~/Applications/VRSmartPlan: VRSmartPlan, VREstimator,
# the planners, VRTAR and VRCMMS. Each opens its tool in its own window (Google Chrome or
# Microsoft Edge in app mode) with a private browser profile, so your records
# are kept apart from normal browsing and are not removed when the browser's
# history is cleared. They also appear in Launchpad and Spotlight.
# Re-running setup updates the program and keeps your records.
#
#   install.sh [--source DIR] [--no-launch]
#   VRSCHEDULER_BROWSER=/path/to/Browser.app   use that browser (testing)

set -u
NAME="VRSmartPlan"
SRC=""
LAUNCH=1
while [ $# -gt 0 ]; do
  case "$1" in
    --source) SRC="$2"; shift 2 ;;
    --no-launch) LAUNCH=0; shift ;;
    *) shift ;;
  esac
done
[ -n "$SRC" ] || SRC="$(cd "$(dirname "$0")/../.." && pwd)"
ROOT="$HOME/Library/Application Support/$NAME"
APP="$ROOT/app"
DATA="$ROOT/profile"          # browser profile: holds your records
APPS="$HOME/Applications/$NAME"

say() { printf '  %s\n' "$*"; }
echo ""
echo "  VRSmartPlan - setup"
echo "  -------------------"
VERSION="$(sed -n 's/^version[[:space:]]*//p' "$SRC/VERSION.txt" 2>/dev/null | head -1 | tr -d '\r')"
[ -n "$VERSION" ] && say "Version: $VERSION"
say "Installing to: $ROOT"
echo ""

if [ ! -f "$SRC/app/index.html" ]; then
  say "The program files were not found next to this setup."
  say "Double-click the zip to extract the whole folder first, then run setup again."
  exit 1
fi

# 1. Close a running VRSmartPlan window so its files can be replaced.
stop_windows() {
  local pids
  pids="$(ps -axo pid=,command= | D="--user-data-dir=$DATA" awk 'index($0, ENVIRON["D"]) { print $1 }')"
  if [ -n "$pids" ]; then kill $pids 2>/dev/null; sleep 1; fi
}
stop_windows

# 1a. First install only: copy the records of the earlier product name (VRProject)
#     into this profile. VRProject itself is left as it was. VRProject is closed first
#     and setup waits until it has exited; caches are skipped. A copy that an
#     earlier setup did not finish is redone.
OLD_DATA="$HOME/Library/Application Support/VRProject/profile"
COPY_MARK="$ROOT/records-copy-unfinished"
redo=0
if [ -d "$DATA" ] && { [ -f "$COPY_MARK" ] || [ ! -f "$APP/index.html" ]; }; then redo=1; fi
if [ -d "$OLD_DATA" ] && { [ ! -d "$DATA" ] || [ "$redo" = 1 ]; }; then
  say "Copying your VRProject records ..."
  old_pids() { ps -axo pid=,command= | D="--user-data-dir=$OLD_DATA" awk 'index($0, ENVIRON["D"]) { print $1 }'; }
  pids="$(old_pids)"
  if [ -n "$pids" ]; then
    say "Closing VRProject so its records can be read ..."
    kill $pids 2>/dev/null
    i=0
    while [ -n "$(old_pids)" ] && [ $i -lt 20 ]; do sleep 0.5; i=$((i+1)); done
    pids="$(old_pids)"; [ -n "$pids" ] && kill -9 $pids 2>/dev/null
    sleep 1
  fi
  rm -rf "$DATA"
  mkdir -p "$ROOT"
  : > "$COPY_MARK"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude 'Cache/' --exclude 'Code Cache/' --exclude 'GPUCache/' --exclude 'Dawn*Cache/'       --exclude 'GrShaderCache/' --exclude 'ShaderCache/' --exclude 'Crashpad/' --exclude 'Singleton*'       --exclude 'lockfile' --exclude 'LOCK' "$OLD_DATA/" "$DATA/"
  else
    cp -R "$OLD_DATA" "$DATA"
    rm -f "$DATA"/Singleton* "$DATA/lockfile"
  fi
  rm -f "$COPY_MARK"
  say "Your VRProject records were copied. VRProject itself was not changed."
fi

# 2. Copy the program. The profile folder (your records) is never touched.
say "Copying VRSmartPlan ..."
mkdir -p "$ROOT" "$DATA"
if [ "$SRC" != "$ROOT" ]; then
  rm -rf "$APP" "$ROOT/setup"
  cp -R "$SRC/app" "$APP"
  mkdir -p "$ROOT/setup"
  cp -R "$SRC/setup/mac" "$ROOT/setup/mac"
  for f in VERSION.txt README.txt; do [ -f "$SRC/$f" ] && cp "$SRC/$f" "$ROOT/"; done
fi
# Files from a download are marked; the copies do not need the mark.
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
chmod +x "$ROOT/setup/mac/"*.sh 2>/dev/null || true

# 3. The browser that shows VRSmartPlan (started with --allow-file-access-from-files so
#    VREstimator can read PDF drawings and run text recognition from the local
#    files; only this separate VRSmartPlan window and profile): Google Chrome, Microsoft Edge,
#    Chromium or Brave. Safari cannot open a page in its own app window.
find_browser() {
  if [ -n "${VRSCHEDULER_BROWSER:-}" ] && [ -d "$VRSCHEDULER_BROWSER" ]; then echo "$VRSCHEDULER_BROWSER"; return; fi
  local b
  for b in "Google Chrome" "Microsoft Edge" "Chromium" "Brave Browser"; do
    for base in "/Applications" "$HOME/Applications"; do
      if [ -d "$base/$b.app" ]; then echo "$base/$b.app"; return; fi
    done
  done
  b="$(mdfind "kMDItemCFBundleIdentifier == 'com.google.Chrome'" 2>/dev/null | head -1)"
  [ -n "$b" ] || b="$(mdfind "kMDItemCFBundleIdentifier == 'com.microsoft.edgemac'" 2>/dev/null | head -1)"
  echo "$b"
}
BROWSER="$(find_browser)"
if [ -n "$BROWSER" ]; then
  say "Opens in: $(basename "$BROWSER" .app) (its own window)"
else
  say "Google Chrome and Microsoft Edge were not found. The tools will open in your default browser;"
  say "install Chrome or Edge and run setup again for their own windows and the links between them."
fi

# 4. The apps: a launcher per tool, built here (so macOS does not hold them as downloads).
urlpath() { python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$1" 2>/dev/null \
  || printf '%s' "$1" | sed 's/ /%20/g'; }
make_app() {   # name, page, bundle id suffix, description
  local name="$1" page="$2" id="$3" desc="$4"
  local bundle="$APPS/$name.app"
  rm -rf "$bundle"
  mkdir -p "$bundle/Contents/MacOS" "$bundle/Contents/Resources"
  cat > "$bundle/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$name</string>
  <key>CFBundleDisplayName</key><string>$name</string>
  <key>CFBundleIdentifier</key><string>com.vissrad.$id</string>
  <key>CFBundleExecutable</key><string>launch</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VERSION%%-*}</string>
  <key>CFBundleGetInfoString</key><string>$desc</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST
  cat > "$bundle/Contents/MacOS/launch" <<LAUNCH
#!/bin/bash
# $desc
ROOT="\$HOME/Library/Application Support/$NAME"
PAGE="\$ROOT/app/$page"
URL="file://$(urlpath "$APP/$page")"
BROWSER="$BROWSER"
if [ ! -f "\$PAGE" ]; then
  osascript -e 'display alert "$name is not installed" message "Run Install VRSmartPlan (Mac) again from the downloaded folder."' >/dev/null 2>&1
  exit 1
fi
if [ -n "\$BROWSER" ] && [ -d "\$BROWSER" ]; then
  open -na "\$BROWSER" --args --app="\$URL" --user-data-dir="\$ROOT/profile" --allow-file-access-from-files --no-first-run --no-default-browser-check
else
  open "\$URL"
fi
LAUNCH
  chmod +x "$bundle/Contents/MacOS/launch"
  [ -f "$APP/assets/AppIcon.icns" ] && cp "$APP/assets/AppIcon.icns" "$bundle/Contents/Resources/AppIcon.icns"
  touch "$bundle"
}
say "Creating the apps in $APPS ..."
mkdir -p "$APPS"
make_app "VRSmartPlan" "index.html" "vrsmartplan" "VRSmartPlan - estimating, scheduling, planning and project controls workbench (opens the VRScheduler Schedule Editor)"
# The tool list is setup/tools.txt: one line per tool, "Name|folder|id|description".
while IFS='|' read -r n f i d; do
  d="${d%$'\r'}"
  case "$n" in ''|'#'*) continue ;; esac
  [ -f "$APP/$f/index.html" ] && make_app "$n" "$f/index.html" "$i" "$d"
done < "$SRC/setup/tools.txt"
cp "$ROOT/setup/mac/uninstall.sh" "$APPS/Uninstall VRSmartPlan.command" && chmod +x "$APPS/Uninstall VRSmartPlan.command"
# Tell Launchpad and Spotlight about the new apps.
LSREG="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
for a in "$APPS"/*.app; do [ -x "$LSREG" ] && "$LSREG" -f "$a" >/dev/null 2>&1; done

echo ""
say "Done. Open VRSmartPlan from Launchpad, Spotlight or $APPS."
say "To keep it in the Dock, open it, then right-click its Dock icon > Options > Keep in Dock."
echo ""
if [ "$LAUNCH" = 1 ]; then open "$APPS/VRSmartPlan.app"; fi
exit 0
