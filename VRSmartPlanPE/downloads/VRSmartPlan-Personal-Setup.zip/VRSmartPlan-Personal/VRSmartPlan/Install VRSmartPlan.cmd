@echo off
rem VRSmartPlan - one-click setup. No admin rights and nothing else to install.
title VRSmartPlan - setup
if not exist "%~dp0setup\install.ps1" (
  echo.
  echo   The setup files are still inside the zip.
  echo.
  echo   1. Close this window.
  echo   2. Right-click the VRSmartPlan zip file and choose "Extract All...".
  echo   3. Open the extracted folder and double-click "Install VRSmartPlan".
  echo.
  echo   Press any key to close.
  pause >nul
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1" -Source "%~dp0."
if errorlevel 1 (
  echo.
  echo   Setup did not finish. Press any key to close.
  pause >nul
)
