# Data center estimating, planning and scheduling: research notes (rev. 4)

Starting benchmarks behind the 25 new VRDCPlanner modules (ids PE-DC-...). Calibrate them to your own history.

## Cost benchmarks
- Construction cost: about $9.8/W (Phoenix, Columbus) to $13.3/W (Silicon Valley), from the Turner & Townsend DCCI 2025 — https://datacenterscouts.com/data-center-construction-cost/
- Cost split for an air-cooled hall: 54% electrical, 22% mechanical, 14% shell, 10% GC. For a liquid-cooled hall: 48 / 33 / 9 / 10, at a 7-10% premium — https://open-factory.com/models/mep-cost-table/
- All-in cost averages $17.6M/MW, with a range of $8.9-23.3M (Cushman & Wakefield 2026) — https://dcbuildx.com/blogs/insights/data-center-building-vs-containerized-construction-cost
- Commissioning runs 2-3% of construction cost — https://www.cortexconstruct.com/blog/how-much-does-it-cost-to-build-a-data-center

## Labor
- Electricians carry 30-40% of craft hours. Mechanical trades carry 15-25% — https://www.cortexconstruct.com/blog/how-many-workers-to-build-data-center
- Peak construction runs 0.7-2.0 workers per MW — https://www.rinvio.com/blog/what-drives-electrician-headcount-in-a-data-hall
- A 60 MW case study peaked at about 7.2 electricians per MW — https://www.rinvio.com/blog/what-drives-electrician-headcount-in-a-data-hall
- AI data centers need about 1,800 electrician-hours per MW — https://www.csis.org/analysis/genais-human-infrastructure-challenge-can-united-states-meet-skilled-trade-labor-demand

## Schedule
- Typical phase durations (months): site selection 3-6, design 6-12, permitting 6-18, sitework 2-4, shell 3-9, MEP 6-12, commissioning 3-6, handover 1-3 — https://starcsystems.com/blog/data-center-construction/
- Shell and core takes 12-24 months, and the full cycle 24-48 months — https://coloprice.com/guides/data-center-construction-process/
- On a phased program, the first hall can be ready in 9-15 months — https://southlandind.com/article/hyperscale-data-center-construction-supporting-ai-infrastructure
- Customer HV substation and interconnection scope and sequence — https://atkenergygroup.com/blog/data-center-substation-construction/ , https://www.pjm.com/pub/planning/project-queues/facilities/aa2115_fac.pdf

## Long-lead equipment (weeks)
- Large power transformers 128 and GSUs 144 (Wood Mackenzie). MV switchgear 44 — https://cmicglobal.com/resources/article/Why-Data-Centers-Break-Traditional-Construction-Forecasting
- Gensets over 3 MW 90-110. UPS 30-48. Busway 16-52. Chillers 40-70. CDUs 26-52. Pad-mount transformers 40-65 — https://savrn.com/research/data-center-supply-chain-crisis

## Commissioning and testing norms
- Commissioning Levels 1-5 (FAT, installation, start-up, functional testing, IST) — https://www.ashrae.org/technical-resources/topics-and-initiatives/ai-data-center/commissioning-performance-validation
- NFPA 110 generator tests: at least 1.5 h on building load, plus a 2 h load bank at 30% / 50% / 100% — https://www.curtispowersolutions.com/nfpa-110-acceptance-testing
- UPS battery acceptance and capacity testing sequence — https://resistancezero.com/cx-handbook/16-ups-batteries-transfer-rack-power.html
- NETA acceptance testing scope (ANSI/NETA ATS) — https://blog.ansi.org/ansi/ansi-neta-ats-2025-electrical-power-testing/
- TCS liquid-cooling pre-commission flush, fill and fluid-quality release (OCP) — https://www.opencompute.org/documents/ocp-document-submission-guidelines-for-pre-commission-preparation-of-technology-cooling-system-tcs-row-manifolds-revq-pdf-1/ , https://www.opencompute.org/wp-content/uploads/2026/10/OCP-PG25-Guidelines-V1.0.0.pdf
- Clean agent rooms: hold 85% of design concentration for 10 min (NFPA 2001 door-fan test) — https://www.nfpa.org/news-blogs-and-articles/blogs/2021/03/12/room-integrity-for-gaseous-fire-suppression-systems
- Pre-action sprinklers: hydrostatic test at 200 psi for 2 h, plus an air test at 40 psi for 24 h — https://moval.gov/departments/fire/pdf/dev-guides/FireSprinklerSystemsNFPA-13.pdf
- AI racks (NVL72 class): high-density receive, set and connect planning — https://gpusmith.com/articles/en/how-to-build-an-ai-datacenter
- Prefabricated power modules deploy 30-50% faster — https://library.e.abb.com/public/32c6aaf0740d4a2f927fc712518d9400/Modular%20prefabricated%20solutions%20speed%20DC%20deployment_Brochure_Final.pdf
- Bridge power runs about $1,700-2,000/kW — https://www.rabobank.com/knowledge/d011524694-the-sprint-data-centers-are-building-a-parallel-energy-system-in-the-us
