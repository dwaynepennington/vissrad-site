# Power plant and nuclear estimating, planning and scheduling: research notes (rev. 5)

Starting benchmarks behind the 58 new modules: VRPowerPlanner (ids PE-PW- and PE-NB-) and VRPowerOutage (ids PE-PO- and PE-NO-). Calibrate them to your own history.

## Power plant builds
- Large US gas turbines now take about six years to deliver (Wood Mackenzie) — https://internationalfinance.com/utilities/data-centres-turn-to-used-turbines-and-jet-engines-as-waits-stretch-into-2030s/
- GE Vernova's gas turbine backlog is about 116 GW — https://www.blackforgedatacenters.com/guides/data-center-equipment-supply-chain
- Recent combined-cycle plants cost $2,000/kW or more — https://www.pjm.com/-/media/DotCom/committees-groups/cifp-rbp/2026/20260630/20260630-item-02e---e-cubed-policy-associates---rbp-additional-posting---gas-turbine-costs.pdf
- Recent deals price combined-cycle plants at about $2,293-2,500/kW — https://www.dcmarketinsights.com/news/venture-globals-11-5-gw-gas-deal-prices-onsite-power-near-us1500-per-kw-ge-vernova-reports-on-28-october
- Steam blows are accepted when the target plate shows 5 pits or fewer — https://ijiset.com/vol3/v3s10/IJISET_V3_I10_10.pdf , https://epcland.com/steam-blowing-procedure/
- HRSG / boiler pre-operational chemical cleaning — https://restservice.epri.com/publicdownload/000000003002011567/0/Product , https://www.ccj-online.com/wp-content/uploads/2022/07/So-I-Need-to-Chemcial-Clean-My-HRSG.pdf
- P91 welding needs controlled preheat, interpass temperature and PWHT — https://www.millerwelds.com/en-us/resources/knowledge-hub/industrial-welding/tube-pipe/meet-the-requirements-of-welding-p91-pipe-with-wire-processes , https://www.sfsa.org/folio/2009-Q2/P91%20and%20Beyond.pdf
- CEMS certification tests (40 CFR 75.20) — https://ecfr.gov/current/title-40/chapter-I/subchapter-C/part-75/subpart-C/section-75.20
- Overhead cranes are load tested at 125% of rated load — https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.179
- Lube oil flushes target ISO 4406 16/14/11 — https://www.lubeoilrecycle.com/news/industry-news/lube-oil-flushing-acceptance-criteria.html
- Transformer oil is filled under vacuum (about 2 torr) — https://www.prolec.energy/wp-content/uploads/2026/10/7-Installation-Procedues-New-Transformer-Oil-Processing-3.pdf
- Black-start capability — https://www.nlr.gov/grid/black-start
- Heavy haul of turbines and generators — https://moveitmagazine.com/2023/04/28/mammoets-transport-with-goldhofer/?currency=EUR

## Fossil, gas and hydro outages
- Freeze scope around T-180 and place long-lead POs by about T-150 — https://oxmaint.com//article/power-plant-outage-turnaround-planning-guide
- Outage management practice (IAEA TECDOC-1315) — https://www-pub.iaea.org/MTCD/Publications/PDF/te_1315_web.pdf
- Air preheater maintenance — https://restservice.epri.com/publicdownload/000000000001018472/0/Product
- Pulverizer maintenance — https://www.stormeng.com/pdf/PerformanceDrivenMaintenanceFeb52013.pdf
- Baghouse outage planning — https://www.micronicsinc.com/wp-content/uploads/Baghouse-Outage-Planning-1_24.pdf
- FGD mist eliminators — https://restservice.epri.com/publicdownload/TR-109108/0/Product
- Generator stator reliability and rewedging — https://irispower.com/wp-content/uploads/2022/01/IRMC-2021-A-30-Years-Reliability-Survey-of-a-Generator-Family-Paper-Ilie.pdf
- Generator hydrogen purge hazards — https://www.osha.gov/sites/default/files/publications/SHIB012216.pdf

## Nuclear refueling outages and maintenance
- Constellation's 2025 refueling outages averaged 21.5 days, about 16 days better than the industry average — https://www.constellationenergy.com/work/generation/nuclear/reliability.html
- Columbia Generating Station (BWR) refueling outages average about 54 days — https://www.nukeworker.com/outages/unit/columbia-generating-station/
- In a PWR outage the critical path is usually refueling or steam generator inspection — https://www.nrc.gov/docs/ML0037/ML003752321.pdf
- Steam generator eddy-current testing took about 10 days in the field at Braidwood — https://www.nrc.gov/docs/ML2309/ML23095A130.pdf
- Holtec averaged 2.8 days pool-to-pad per canister at St. Lucie — https://www.ans.org/news/2025-11-10/article-7529/st-lucie-dry-storage-campaign-completed-in-record-time-holtec-says
- Maintenance Rule, including (a)(4) risk assessment for online work — http://www.ecfr.gov/current/title-10/section-50.65
- ALARA outage planning (Palo Verde) — https://www.ans.org/pubs/magazines/download/article-810/

## Nuclear new builds
- Vogtle 3 and 4 cost about $36B over roughly 15 years — https://www.powermag.com/what-was-learned-from-building-new-nuclear-reactors/
- The independent monitor found Vogtle lacked a realistic schedule — https://www.energypolicy.columbia.edu/wp-content/uploads/2026/11/Vogtle-CGEP_Report_111126.pdf
- Large-reactor costs are about $15,700/kW — https://www.irecruit.co/guides/nuclear-power-plant-construction-cost
- AP1000 hot functional testing runs the RCPs at full flow for at least 240 h, half of that at 515°F or above — https://www.nrc.gov/docs/ML0832/ML083230235.pdf
- The BWRX-300 targets about 36 months from first nuclear concrete to fuel load — https://www.gevernova.com/nuclear/carbon-free-power/bwrx-300-small-modular-reactor
- The BWRX-300 targets 24-36 month construction and 10-15 day outages — https://www.gevernova.com/content/dam/gevernova-nuclear/global/en_us/documents/carbon-free-power/005N9751-BWRX-300-General-Description.pdf
- ITAAC process and closure — https://www.nrc.gov/facilities-safety/new-reactors/how-we-regulate/regulatory-oversight/inspections-tests-analyses-and-acceptance-criteria-itaac , https://www.nrc.gov/docs/ML1510/ML15105A447.pdf
- Safety-related (NQA-1) concrete — https://www.nrc.gov/docs/ML2603/ML26034C018.pdf
- An open-top lift set a 330 t reactor vessel with a Liebherr LR 13000 — https://www.world-nuclear-news.org/Articles/Reactor-vessel-installed-at-first-Turkish-unit
- Advanced construction methods (modules, open-top) — https://www.nrc.gov/docs/ML1214/ML12146A152.pdf

## New crafts and equipment added
- VRPowerOutage: RP (radiation protection technician), DCN (decontamination technician), FH (fuel handler), ROB (robotic inspection system) and HEPA (ventilation unit).
- VRPowerPlanner: NQ (NQA-1 inspector), RP, FH and HLC (heavy-lift ring crane).
- Rates are starting values. Importing never changes rates you already have.
