Personal modules for the VRSmartPlan planner tools (personal use only)

Each file holds the modules that fit that planner. Importing adds only the crew, equipment and
price-book codes the planner is missing; it never changes your existing rates.

HOW TO IMPORT: open the planner > Module Editor > Import / export > Import library... > pick its file.
Import merges by id, so importing again later is safe.

VRPlanner              235 modules  file: VRPlanner-Personal-Modules.json
    categories: Civil & structural, Coatings & insulation, Columns & vessels, Electrical, Fired equipment, General, Heat transfer, Instruments & controls, Planning & engineering, Rotating equipment, Tanks, Valves & piping
    renamed to avoid a clash with this planner's codes: PW->PW-T, SV->SV-T, REBAR->REBAR-T

VRDCPlanner             70 modules  file: VRDCPlanner-Personal-Modules.json
    categories: Electrical, Instruments & controls, Civil & structural, Coatings & insulation, General, Planning & engineering
    renamed to avoid a clash with this planner's codes: SV->SV-T, REBAR->REBAR-T

VRE&IPlanner            55 modules  file: VREandIPlanner-Personal-Modules.json
    categories: Electrical, Instruments & controls, General, Planning & engineering

VRPowerPlanner         235 modules  file: VRPowerPlanner-Personal-Modules.json
    categories: Civil & structural, Coatings & insulation, Columns & vessels, Electrical, Fired equipment, General, Heat transfer, Instruments & controls, Planning & engineering, Rotating equipment, Tanks, Valves & piping
    renamed to avoid a clash with this planner's codes: REBAR->REBAR-T

VRPowerOutage          244 modules  file: VRPowerOutage-Personal-Modules.json
    categories: Civil & structural, Coatings & insulation, Columns & vessels, Electrical, Fired equipment, General, Heat transfer, Instruments & controls, Planning & engineering, Rotating equipment, Tanks, Turnaround event, Valves & piping
    renamed to avoid a clash with this planner's codes: VLV-KIT->VLV-KIT-T

VRUpstreamPlanner      235 modules  file: VRUpstreamPlanner-Personal-Modules.json
    categories: Civil & structural, Coatings & insulation, Columns & vessels, Electrical, Fired equipment, General, Heat transfer, Instruments & controls, Planning & engineering, Rotating equipment, Tanks, Valves & piping
    renamed to avoid a clash with this planner's codes: SB->SB-T, REBAR->REBAR-T

VRMidstreamPlanner     235 modules  file: VRMidstreamPlanner-Personal-Modules.json
    categories: Civil & structural, Coatings & insulation, Columns & vessels, Electrical, Fired equipment, General, Heat transfer, Instruments & controls, Planning & engineering, Rotating equipment, Tanks, Valves & piping
    renamed to avoid a clash with this planner's codes: SB->SB-T, SV->SV-T, REBAR->REBAR-T

VRRailHighwayPlanner    52 modules  file: VRRailHighwayPlanner-Personal-Modules.json
    categories: Civil & structural, Electrical, Coatings & insulation, General, Planning & engineering
    renamed to avoid a clash with this planner's codes: FL->FL-T, SV->SV-T, REBAR->REBAR-T

Renames: these codes mean something different in some planners (SV = surveyor, PW = cable puller,
SB = side boom, FL = highway flagger, REBAR priced per ton, VLV-KIT = general valve kit), so the
modules use a '-T' copy carrying the VRTAR meaning and rate. Equivalent crafts (e.g. QC inspector,
electrician) use the planner's own code and rate.
