VRSmartPlan - Personal Edition (personal use only, not for redistribution)
Built 2026-11-16 (rev. 2: modules preloaded in all planners)

WHAT'S INSIDE
  VRSmartPlan\                          The VRSmartPlan app with your 244 personal modules
                                        preloaded in VRTAR and in all eight planners:
                                          VRTAR 330, VRPlanner 269, VRDCPlanner 103,
                                          VRE&IPlanner 87, VRPowerPlanner 260,
                                          VRPowerOutage 268, VRUpstreamPlanner 254,
                                          VRMidstreamPlanner 256, VRRailHighwayPlanner 82.
  VRTAR-Personal-Module-Library.json    The same 244 modules as an importable library file.
  Planner-libraries\                    One import file per planner tool (see README-PLANNERS.txt).
  VRTAR-Personal-Module-Library.xlsx    Editable workbook: Index tab, one tab per module
                                        (questions, tasks, crews, equipment, materials),
                                        Resources tab and Dictionary tab.

INSTALL ON YOUR PC (Windows)
  1. Right-click the ZIP > Extract All (do not run from inside the ZIP).
  2. Open VRSmartPlan-Personal\VRSmartPlan and double-click "Install VRSmartPlan.cmd".
  3. Start VRSmartPlan from the desktop / Start-menu shortcut, then open VRTAR >
     Module Editor > Modules. Your modules show Source = "Mine". Each planner's module
     list shows the counts above.
  Note: this installs to %LOCALAPPDATA%\VRSmartPlan, replacing any existing VRSmartPlan
  install with this same build plus your modules. Your saved project records are kept.

ADD THE MODULES TO ANOTHER COPY (optional)
  VRTAR > Module Editor > Import / export > Import library... > choose
  VRTAR-Personal-Module-Library.json. Import merges by id, so re-importing is safe.
  For the planner tools use the matching file in Planner-libraries (it adds any missing
  crew, equipment and price-book codes without changing your rates).

ABOUT THE MODULES
  These are original VissRad task templates authored from your module list titles and
  general industry practice. They are not copies of eTaskMaker module content.
  Durations, crews and quantities are starting values: calibrate them to your own history
  in the Module Editor (or edit in the workbook and re-enter). Module ids start with "PG-".

UPDATING FROM THE EARLIER BUILD
  Either reinstall from this ZIP, or re-import VRTAR-Personal-Module-Library.json (and the
  planner files). Import replaces modules with the same id, so nothing is duplicated.
  Reinstall from this ZIP to get the planner modules preloaded (the earlier ZIP only
  preloaded VRTAR; its planners showed the standard VissRad counts).
  The 244-module build adds 2 modules (Equipment Foundation Drawings, Underground Electrical) and
  corrects step durations in 22 modules that were understated.
