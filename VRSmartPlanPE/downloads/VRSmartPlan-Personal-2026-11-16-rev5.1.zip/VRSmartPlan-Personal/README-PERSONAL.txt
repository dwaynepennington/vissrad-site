VRSmartPlan - Personal Edition (personal use only, not for redistribution)
Built 2026-11-16 (rev. 5.1: nuclear outage planning scales to its horizon; rev. 5: power plant and nuclear deep dive, 58 more new modules; rev. 4 data center deep dive; rev. 3 filtered planners to scope)

WHAT'S INSIDE
  VRSmartPlan\                          The VRSmartPlan app with your personal modules preloaded.
                                        VRTAR carries all 244; each planner carries only the
                                        ones that fit its area of planning, plus new modules:
                                          VRTAR 330, VRPlanner 118, VRDCPlanner 92,
                                          VRE&IPlanner 67, VRPowerPlanner 114,
                                          VRPowerOutage 178, VRUpstreamPlanner 77,
                                          VRMidstreamPlanner 77, VRRailHighwayPlanner 58.
  VRTAR-Personal-Module-Library.json    The same 244 modules as an importable library file.
  Planner-libraries\                    One import file per planner tool (see README-PLANNERS.txt).
  VRTAR-Personal-Module-Library.xlsx    Editable workbook: Index tab, one tab per module
                                        (questions, tasks, crews, equipment, materials),
                                        Resources tab and Dictionary tab.

INSTALL ON YOUR PC (Windows)
  1. Right-click the ZIP > Extract All (do not run from inside the ZIP).
  2. Open VRSmartPlan-Personal\VRSmartPlan and double-click "Install VRSmartPlan.cmd".
  3. Start VRSmartPlan from the desktop / Start-menu shortcut, then open VRTAR >
     Module Editor > Modules. Your modules show Source = "Mine". Each planner's module
     list shows the counts above.
  Note: this installs to %LOCALAPPDATA%\VRSmartPlan, replacing any existing VRSmartPlan
  install with this same build plus your modules. Your saved project records are kept.

ADD THE MODULES TO ANOTHER COPY (optional)
  VRTAR > Module Editor > Import / export > Import library... > choose
  VRTAR-Personal-Module-Library.json. Import merges by id, so re-importing is safe.
  For the planner tools use the matching file in Planner-libraries (it adds any missing
  crew, equipment and price-book codes without changing your rates).

ABOUT THE MODULES
  These are original VissRad task templates authored from your module list titles and
  general industry practice. They are not copies of eTaskMaker module content.
  Durations, crews and quantities are starting values: calibrate them to your own history
  in the Module Editor (or edit in the workbook and re-enter). Module ids start with "PG-".
  The 115 planner-only modules (ids "PE-") were authored for scopes found during the rev. 3
  review, the rev. 4 data center and rev. 5 power / nuclear deep dives, in each planner's own crafts, equipment
  and price book; Planner-libraries\
  README-PLANNERS.txt lists them and what was removed from each planner and why.

UPDATING FROM THE EARLIER BUILD
  Either reinstall from this ZIP, or re-import VRTAR-Personal-Module-Library.json (and the
  planner files). Import replaces modules with the same id, so nothing is duplicated.
  Reinstall from this ZIP to get the planner modules preloaded (the earlier ZIP only
  preloaded VRTAR; its planners showed the standard VissRad counts).
  Rev. 5.1: the nuclear refueling-outage planning module now sizes every step from its
  planning-horizon input, so its critical path equals the horizon (26-156 weeks).
  Rev. 5 adds 27 modules to VRPowerPlanner (16 power-plant build scopes plus 11 in a new
  Nuclear category: licensing and ITAAC, NQA-1, Q concrete, modules, containment, NSSS set,
  ASME III piping, cold hydro / hot functional test, fuel load, SMR, security) and 31 to
  VRPowerOutage (17 fossil, gas and hydro outage scopes plus 14 Nuclear: refueling planning,
  reactor disassembly / reassembly, refueling, steam generators, RCP seals, ISI, BWR in-vessel,
  LLRT, EDG, online work weeks, RP / FME, dry cask, radwaste). See Power-and-Nuclear-Planning-Notes.md.
  Rev. 4 adds 25 researched data center modules to VRDCPlanner (substation, long-lead
  tracker, program milestones, MOPs, NETA, arc flash, generator and battery acceptance,
  eHouses, bridge power, BESS, TCS flush, RDHx, immersion, towers, TAB, AI racks, leak
  detection, pre-action, clean agent, fire water, perimeter, OSP fiber, paving, cleaning).
  Rev. 3 removes out-of-scope personal modules from the planners (e.g. motor overhauls and
  breaker PM no longer appear in VRDCPlanner, refinery insulation no longer in
  VRRailHighwayPlanner). Reinstalling replaces the preloaded lists. If you imported the
  older planner JSON files into a browser, those copies stay until you delete them there.
  The 244-module build adds 2 modules (Equipment Foundation Drawings, Underground Electrical) and
  corrects step durations in 22 modules that were understated.
