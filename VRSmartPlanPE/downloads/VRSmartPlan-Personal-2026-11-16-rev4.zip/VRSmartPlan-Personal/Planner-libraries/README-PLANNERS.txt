Personal modules for the VRSmartPlan planner tools (personal use only) - rev. 4, 2026-11-16

Each file holds only the personal modules that fit that planner's area of planning, with
categories renamed to the planner's own category names, plus new modules (ids PE-...) for scopes
found during the reviews. Rev. 4 adds 25 researched data center modules to VRDCPlanner.
Importing adds only the crew, equipment and price-book codes the planner is missing; it never
changes your existing rates.

HOW TO IMPORT: open the planner > Module Editor > Import / export > Import library... > pick its file.
Import merges by id. It does not delete modules, so if you imported the rev. 1 / rev. 2 files into a
browser, delete the out-of-scope PG- modules there or clear that planner's saved data first.

VRPlanner               84 modules (78 personal + 6 new); planner total 118 (rev. 3: 118)  file: VRPlanner-Personal-Modules.json
    scope: Capital and brownfield construction: installs, erection, replacement, demolition, tie-ins, civil, E&I, coatings. Pure overhaul / clean / inspect / PM modules and refinery turnaround events removed.
    new: Fireproofing — cementitious, structural steel and skirts; Line flushing, air blowing and steam blowing; Pre-assembled module or skid — set and hook-up; Structural steel demolition; Electric heat tracing — install and test; Shutdown tie-ins — cold cut and weld
    renamed to avoid a clash with this planner's codes: PW->PW-T, SV->SV-T, REBAR->REBAR-T

VRDCPlanner             59 modules (30 personal + 29 new); planner total 92 (rev. 3: 67)  file: VRDCPlanner-Personal-Modules.json
    scope: Data-center build: foundations, duct bank, raceway and cable, panels, transformers, controls, chilled-water piping, pumps and insulation, plus the rev. 4 deep dive (substation, procurement and program, testing and acceptance, on-site power, liquid cooling, AI racks, fire, security, site). Refinery, rotating-equipment overhaul and breaker / motor PM modules removed.
    new: Lightning protection and surge protection; Firestopping and penetration seals; HVAC ductwork — electrical, battery and support rooms; Plumbing and drainage — domestic water, sanitary, roof and condensate drains; Data center program milestones — design through ready for service; Long-lead equipment — submittals, release, fabrication, FAT and delivery; Live data center work — MOPs, change control and maintenance windows; Pre-commissioning cleaning — ISO 14644-1 Class 8 white space; Customer HV substation (115-230 kV) and utility interconnection; Perimeter security — anti-climb fence, crash-rated gates and bollards; Outside plant fiber — HDD conduit, handholes and diverse carrier entrances; Site paving, roads and stormwater detention; Fire water — fire pump, storage tank and underground fire loop; NETA acceptance testing — switchgear, breakers, relays, transformers and MV cable; Short-circuit, coordination and arc-flash study, settings and labels; Generator acceptance — NFPA 110 on-site test and load bank; UPS battery acceptance and capacity testing (IEEE 450 / 1188); Prefabricated power skid or eHouse — receive, set and hook-up; Bridge / on-site gas power — reciprocating engine plant; Battery energy storage system (BESS) — containerized; Liquid cooling — TCS hydrotest, staged flush, fill and water-quality release; Rear-door heat exchangers — install, connect and commission; Immersion cooling — tanks, CDUs, piping and dielectric fill; Cooling towers and condenser water — water-cooled plant; Hydronic cleaning, water treatment and test-and-balance; AI / GPU high-density racks — receive, move, set and connect (NVL72 class); Leak detection — sensing cable, point sensors and BMS alarms; Pre-action sprinkler zones — valve stations, piping, air and trip tests; Clean agent suppression and door-fan room integrity test
    renamed to avoid a clash with this planner's codes: PW->PW-T, SV->SV-T, REBAR->REBAR-T

VRE&IPlanner            35 modules (31 personal + 4 new); planner total 67 (rev. 3: 67)  file: VREandIPlanner-Personal-Modules.json
    scope: E&I installation and calibration: raceway, cable, panels, transformers, poles and lines, DCS / PLC / consoles, instrument installs. Motor overhauls, breaker / disconnect / starter PM, insulator, radiator and cable-rejuvenation maintenance removed.
    new: Fire and gas detection system; Process analyzers and analyzer shelter; Lightning protection and surge protection; Plant telecom — PAGA, CCTV and radio

VRPowerPlanner          62 modules (58 personal + 4 new); planner total 87 (rev. 3: 87)  file: VRPowerPlanner-Personal-Modules.json
    scope: Power-plant new build: civil and structural, BOP piping incl. P91 chrome, pumps, air coolers, exchangers, feedwater heaters, vessels, E&I, insulation. Refinery equipment, maintenance and tank modules removed.
    new: Water treatment and demineralization plant; Fire protection water system — pumps, loop, hydrants and deluge; Circulating water piping — large bore; Backup fuel oil storage and forwarding
    renamed to avoid a clash with this planner's codes: REBAR->REBAR-T

VRPowerOutage          123 modules (119 personal + 4 new); planner total 147 (rev. 3: 147)  file: VRPowerOutage-Personal-Modules.json
    scope: Power-plant outages (any fuel): valves, piping repairs, feedwater heaters, exchangers, cooling towers, screens, steam turbine, pumps, compressors, motors and electrical PM, instruments, boilers and refractory, deaerator, ESP and scrubbers. Refinery process units (FCC, reformer, alky, coker, crude, catalyst, towers) and new construction removed.
    new: Surface condenser — waterbox clean, eddy current and tube plugging; Isolated phase bus — inspect, clean and hipot; High-energy piping and hanger inspection; Station batteries and chargers — test and service
    renamed to avoid a clash with this planner's codes: VLV-KIT->VLV-KIT-T

VRUpstreamPlanner       58 modules (55 personal + 3 new); planner total 77 (rev. 3: 77)  file: VRUpstreamPlanner-Personal-Modules.json
    scope: Upstream construction: wellsite and central-facility piping, flare lines, pumps, coolers, vessels, foundations and racks, E&I incl. poles and overhead lines. Maintenance, refinery and tank modules removed.
    new: Conductor pipe, cellars and rig-ready pad; Flowback and well-test equipment set-up; Interim reclamation and site restoration
    renamed to avoid a clash with this planner's codes: SB->SB-T, REBAR->REBAR-T

VRMidstreamPlanner      56 modules (53 personal + 3 new); planner total 77 (rev. 3: 77)  file: VRMidstreamPlanner-Personal-Modules.json
    scope: Midstream construction: station and terminal piping, flare lines, pumps, air coolers, exchangers, vessels, foundations, E&I, line demolition. Maintenance, refinery, tank and pole modules removed.
    new: In-line inspection run — cleaning, gauging and caliper; Hot tap and Stopple bypass tie-in; Pipeline abandonment in place
    renamed to avoid a clash with this planner's codes: SB->SB-T, SV->SV-T, REBAR->REBAR-T

VRRailHighwayPlanner    28 modules (24 personal + 4 new); planner total 58 (rev. 3: 58)  file: VRRailHighwayPlanner-Personal-Modules.json
    scope: Rail and heavy highway: drainage pipe, foundations, concrete repairs, anchor bolts, duct bank and conduit, poles and lines, panels, bridge metallizing (TSA), hydrodemolition. All plant equipment, piping and insulation modules removed.
    new: Noise barrier walls — post and precast panel; Concrete pavement restoration (CPR); CWR destressing and thermite welding; Pipe culvert lining — CIPP or slip-lining
    renamed to avoid a clash with this planner's codes: FL->FL-T, SV->SV-T, REBAR->REBAR-T

Renames: these codes mean something different in some planners (SV = surveyor, PW = cable puller,
SB = side boom, FL = highway flagger, REBAR priced per ton, VLV-KIT = general valve kit), so the
modules use a '-T' copy carrying the VRTAR meaning and rate. Equivalent crafts (e.g. QC inspector,
electrician) use the planner's own code and rate.

Data center norms (rev. 4) are researched starting values with sources in each module's references:
OCP TCS pre-commission guidance, NFPA 13 / 20 / 110 / 2001, ANSI/NETA ATS, IEEE 450 / 1584, ISO 14644-1,
and 2025-26 lead-time and phase-duration benchmarks. Calibrate to your own history.

VRTAR keeps all 244 personal modules (330 total): it covers every turnaround and maintenance scope.
