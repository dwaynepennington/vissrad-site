VRSmartPlan - Personal Edition (personal use only, not for redistribution)
Built 2026-11-16 (rev. 4: VRDCPlanner data center deep dive, 25 more new modules; rev. 3 filtered planners to scope)

WHAT'S INSIDE
  VRSmartPlan\                          The VRSmartPlan app with your personal modules preloaded.
                                        VRTAR carries all 244; each planner carries only the
                                        ones that fit its area of planning, plus new modules:
                                          VRTAR 330, VRPlanner 118, VRDCPlanner 92,
                                          VRE&IPlanner 67, VRPowerPlanner 87,
                                          VRPowerOutage 147, VRUpstreamPlanner 77,
                                          VRMidstreamPlanner 77, VRRailHighwayPlanner 58.
  VRTAR-Personal-Module-Library.json    The same 244 modules as an importable library file.
  Planner-libraries\                    One import file per planner tool (see README-PLANNERS.txt).
  VRTAR-Personal-Module-Library.xlsx    Editable workbook: Index tab, one tab per module
                                        (questions, tasks, crews, equipment, materials),
                                        Resources tab and Dictionary tab.

INSTALL ON YOUR PC (Windows)
  1. Right-click the ZIP > Extract All (do not run from inside the ZIP).
  2. Open VRSmartPlan-Personal\VRSmartPlan and double-click "Install VRSmartPlan.cmd".
  3. Start VRSmartPlan from the desktop / Start-menu shortcut, then open VRTAR >
     Module Editor > Modules. Your modules show Source = "Mine". Each planner's module
     list shows the counts above.
  Note: this installs to %LOCALAPPDATA%\VRSmartPlan, replacing any existing VRSmartPlan
  install with this same build plus your modules. Your saved project records are kept.

ADD THE MODULES TO ANOTHER COPY (optional)
  VRTAR > Module Editor > Import / export > Import library... > choose
  VRTAR-Personal-Module-Library.json. Import merges by id, so re-importing is safe.
  For the planner tools use the matching file in Planner-libraries (it adds any missing
  crew, equipment and price-book codes without changing your rates).

ABOUT THE MODULES
  These are original VissRad task templates authored from your module list titles and
  general industry practice. They are not copies of eTaskMaker module content.
  Durations, crews and quantities are starting values: calibrate them to your own history
  in the Module Editor (or edit in the workbook and re-enter). Module ids start with "PG-".
  The 57 planner-only modules (ids "PE-") were authored for scopes found during the rev. 3
  review and the rev. 4 data center deep dive, in each planner's own crafts, equipment
  and price book; Planner-libraries\
  README-PLANNERS.txt lists them and what was removed from each planner and why.

UPDATING FROM THE EARLIER BUILD
  Either reinstall from this ZIP, or re-import VRTAR-Personal-Module-Library.json (and the
  planner files). Import replaces modules with the same id, so nothing is duplicated.
  Reinstall from this ZIP to get the planner modules preloaded (the earlier ZIP only
  preloaded VRTAR; its planners showed the standard VissRad counts).
  Rev. 4 adds 25 researched data center modules to VRDCPlanner (substation, long-lead
  tracker, program milestones, MOPs, NETA, arc flash, generator and battery acceptance,
  eHouses, bridge power, BESS, TCS flush, RDHx, immersion, towers, TAB, AI racks, leak
  detection, pre-action, clean agent, fire water, perimeter, OSP fiber, paving, cleaning).
  Rev. 3 removes out-of-scope personal modules from the planners (e.g. motor overhauls and
  breaker PM no longer appear in VRDCPlanner, refinery insulation no longer in
  VRRailHighwayPlanner). Reinstalling replaces the preloaded lists. If you imported the
  older planner JSON files into a browser, those copies stay until you delete them there.
  The 244-module build adds 2 modules (Equipment Foundation Drawings, Underground Electrical) and
  corrects step durations in 22 modules that were understated.
